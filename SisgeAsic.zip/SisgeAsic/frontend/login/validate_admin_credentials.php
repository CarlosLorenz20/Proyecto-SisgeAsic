<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Evita cualquier salida antes del JSON
ob_start();

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432";
$dbname = "bd_asic";
$user = "postgres";
$password = "30429913";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    ob_clean(); // Limpia cualquier salida previa
    echo json_encode(['valid' => false, 'error' => 'Error de conexión a la base de datos']);
    exit;
}

// Obtiene los datos enviados desde el cliente
$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'] ?? '';
$inputPassword = $data['password'] ?? '';

// Verifica que los datos enviados no estén vacíos
if (empty($username) || empty($inputPassword)) {
    ob_clean();
    echo json_encode(['valid' => false, 'error' => 'Usuario o contraseña no proporcionados']);
    exit;
}

// Consulta para obtener el usuario y la contraseña del administrador
$query = "SELECT \"contraseña\" FROM usuario WHERE nombre_usuario = $1 AND id_rol = (SELECT id_rol FROM rol_usuario WHERE nombre_rol = 'Administrador')";
$result = pg_query_params($conn, $query, [$username]);

if ($result && pg_num_rows($result) > 0) {
    $row = pg_fetch_assoc($result);
    $storedPassword = $row['contraseña'];

    // Verifica si la contraseña ingresada coincide con la almacenada
    if ($inputPassword === $storedPassword) { // Comparación directa
        ob_clean(); // Limpia cualquier salida previa
        echo json_encode(['valid' => true]);
    } else {
        ob_clean(); // Limpia cualquier salida previa
        echo json_encode(['valid' => false, 'error' => 'Contraseña incorrecta']);
    }
} else {
    ob_clean(); // Limpia cualquier salida previa
    echo json_encode(['valid' => false, 'error' => 'Usuario no encontrado o no es administrador']);
}

// Cierra la conexión
pg_close($conn);
exit;
?>
