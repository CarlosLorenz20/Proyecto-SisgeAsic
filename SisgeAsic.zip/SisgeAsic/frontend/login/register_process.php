<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432";
$dbname = "bd_asic";
$user = "postgres";
$password = "30429913";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Error de conexión: " . pg_last_error());
}

// Depuración: Imprime las claves y valores de $_POST
echo "<pre>";
print_r($_POST);
echo "</pre>";

// Normaliza las claves y valores de $_POST a UTF-8
foreach ($_POST as $key => $value) {
    $normalizedKey = mb_convert_encoding($key, 'UTF-8', mb_detect_encoding($key));
    $normalizedValue = mb_convert_encoding($value, 'UTF-8', mb_detect_encoding($value));
    $_POST[$normalizedKey] = $normalizedValue;
}

// Obtiene los datos del formulario
$nombre_usuario = $_POST['nombre_usuario'] ?? '';
$nombre = $_POST['nombre'] ?? '';
$correo_electronico = $_POST['correo_electronico'] ?? null;
$contrasena = $_POST['contraseña'] ?? ''; // Cambiado a 'contraseña' con ñ
$id_rol = $_POST['id_rol'] ?? '';

// Depuración: Verifica qué campos están vacíos
if (empty($nombre_usuario)) {
    die("Error: El campo 'nombre_usuario' está vacío.");
}
if (empty($nombre)) {
    die("Error: El campo 'nombre' está vacío.");
}
if (empty($contrasena)) {
    die("Error: El campo 'contraseña' está vacío.");
}
if (empty($id_rol)) {
    die("Error: El campo 'id_rol' está vacío.");
}

// Inserta los datos en la base de datos
$query = "INSERT INTO usuario (nombre_usuario, nombre, correo_electronico, \"contraseña\", id_rol) 
          VALUES ($1, $2, $3, $4, $5)"; // Se omite 'id_usuario' porque PostgreSQL lo genera automáticamente
$result = pg_query_params($conn, $query, [$nombre_usuario, $nombre, $correo_electronico, $contrasena, $id_rol]);

if (!$result) {
    die("Error al registrar el usuario: " . pg_last_error($conn));
}

echo "Usuario registrado exitosamente.";
pg_close($conn);
?>
