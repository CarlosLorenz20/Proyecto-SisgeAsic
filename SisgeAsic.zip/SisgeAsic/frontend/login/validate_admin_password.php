<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Evita cualquier salida antes del JSON
ob_start();

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432";
$dbname = "bd_asic";
$user = "postgres";
$password = "30429913";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    ob_clean(); // Limpia cualquier salida previa
    echo json_encode(['valid' => false, 'error' => 'Error de conexión a la base de datos']);
    exit;
}

// Obtiene la contraseña enviada desde el cliente
$data = json_decode(file_get_contents('php://input'), true);
$inputPassword = $data['password'] ?? '';

// Consulta para obtener la contraseña cifrada del administrador
$query = "SELECT contrasena FROM usuario WHERE id_rol = (SELECT id_rol FROM rol_usuario WHERE nombre_rol = 'Administrador') LIMIT 1";
$result = pg_query($conn, $query);

if ($result && pg_num_rows($result) > 0) {
    $row = pg_fetch_assoc($result);
    $hashedPassword = $row['contrasena'];

    // Verifica si la contraseña ingresada coincide con la almacenada
    if (password_verify($inputPassword, $hashedPassword)) {
        ob_clean(); // Limpia cualquier salida previa
        echo json_encode(['valid' => true]);
    } else {
        ob_clean(); // Limpia cualquier salida previa
        echo json_encode(['valid' => false, 'error' => 'Contraseña incorrecta']);
    }
} else {
    ob_clean(); // Limpia cualquier salida previa
    echo json_encode(['valid' => false, 'error' => 'No se encontró un administrador registrado']);
}

pg_close($conn);
exit;
?>
