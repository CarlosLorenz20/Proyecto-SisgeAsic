<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432";
$dbname = "bd_asic";
$user = "postgres";
$password = "30429913";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Error de conexión: " . pg_last_error());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SisgeAsic - Registro</title>

    <!-- Custom fonts for this template-->
    <script src="https://kit.fontawesome.com/7a4cab1fbd.js" crossorigin="anonymous"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../dashboard/css/sb-admin-2.css" rel="stylesheet">
</head>

<body class="bg-gradient-primary">

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const roleSelect = document.querySelector("select[name='id_rol']");

            roleSelect.addEventListener("change", function () {
                if (this.options[this.selectedIndex].text === "Administrador") {
                    const adminUser = prompt("Introduce el usuario del administrador:");
                    const adminPassword = prompt("Introduce la contraseña del administrador:");
                    
                    if (adminUser && adminPassword) {
                        // Realiza una solicitud AJAX para validar el usuario y la contraseña
                        fetch("validate_admin_credentials.php", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                            },
                            body: JSON.stringify({ username: adminUser, password: adminPassword }),
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (!data.valid) {
                                alert("Usuario o contraseña incorrectos. No puedes seleccionar el rol de Administrador.");
                                roleSelect.value = ""; // Reinicia la selección
                            } else {
                                alert("Credenciales correctas. Puedes seleccionar el rol de Administrador.");
                                // No se reinicia el valor del select
                            }
                        })
                        .catch(error => {
                            console.error("Error al validar las credenciales:", error);
                            alert("Ocurrió un error al validar las credenciales.");
                            roleSelect.value = ""; // Reinicia la selección
                        });
                    } else {
                        this.value = ""; // Reinicia la selección si no se introducen datos
                    }
                }
            });
        });
    </script>

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">¡Crea una cuenta!</h1>
                            </div>
                            <form class="user" action="register_process.php" method="POST" onsubmit="return validateForm();">
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="nombre_usuario"
                                        placeholder="Nombre de usuario" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="nombre"
                                        placeholder="Nombre" required>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control form-control-user" name="correo_electronico"
                                        placeholder="Correo electrónico">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control form-control-user" name="contraseña"
                                        placeholder="Contraseña" required> <!-- Asegúrate de que el atributo name sea 'contraseña' -->
                                </div>
                                <div class="form-group">
                                    <select class="form-control form-control-user" name="id_rol" required>
                                        <option value="">Selecciona un rol</option>
                                        <?php
                                        $query = "SELECT id_rol, nombre_rol FROM rol_usuario";
                                        $result = pg_query($conn, $query);

                                        if (!$result) {
                                            echo "<option value=''>Error en la consulta: " . pg_last_error($conn) . "</option>";
                                        } elseif (pg_num_rows($result) > 0) {
                                            while ($row = pg_fetch_assoc($result)) {
                                                echo "<option value='{$row['id_rol']}'>{$row['nombre_rol']}</option>";
                                            }
                                        } else {
                                            echo "<option value=''>No hay roles disponibles</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block">
                                    Registrar cuenta
                                </button>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="forgot-password.html">¿Has olvidado tu contraseña?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="login.php">¿Ya tienes una cuenta? ¡Inicia sesión!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>