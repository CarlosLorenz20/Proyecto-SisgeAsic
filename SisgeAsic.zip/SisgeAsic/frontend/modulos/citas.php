<?php
// Conexión a la base de datos
include_once '../../backend/bdPostGre/conexion.php'; // Archivo de conexión proporcionado

try {
    // Consultar médicos
    $queryMedicos = "SELECT id_medico, pr_nombre, pr_apellido FROM medico";
    $stmtMedicos = $pdo->query($queryMedicos);
    $medicos = $stmtMedicos->fetchAll(PDO::FETCH_ASSOC);

    // Consultar pacientes
    $queryPacientes = "SELECT cedula, pr_nombre, pr_apellido FROM paciente";
    $stmtPacientes = $pdo->query($queryPacientes);
    $pacientes = $stmtPacientes->fetchAll(PDO::FETCH_ASSOC);

    // Consultar especialidades con colores
    $queryEspecialidades = "SELECT id_especialidad, nombre_especialidad, color FROM especialidad";
    $stmtEspecialidades = $pdo->query($queryEspecialidades);
    $especialidades = $stmtEspecialidades->fetchAll(PDO::FETCH_ASSOC);

    // Consultar citas
    $queryCitas = "SELECT id, titulo, fecha_inicio, fecha_fin, color FROM cita"; // Cambiado a 'cita'
    $stmtCitas = $pdo->query($queryCitas);
    $citas = $stmtCitas->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error en las consultas: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Configuración básica del documento -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Carga de iconos y estilos -->
    <script src="https://kit.fontawesome.com/7a4cab1fbd.js" crossorigin="anonymous"></script>
    <title>SisgeAsic - Panel Admin</title>
    <link rel="icon" type="image/png" sizes="96x96" href="../img/logo2.png">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="../dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../dashboard/css/sb-admin-2.css" rel="stylesheet">
    <style>
        .color-circle {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
            vertical-align: middle;
        }

        .dropdown {
            position: relative;
            display: inline-block;
            width: 100%;
        }

        .dropdown-button {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #fff;
            cursor: pointer;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            z-index: 10;
            width: 100%;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-height: 200px;
            overflow-y: auto;
        }

        .dropdown-menu.active {
            display: block;
        }

        .dropdown-item {
            display: flex;
            align-items: center;
            padding: 8px 12px;
            cursor: pointer;
        }

        .dropdown-item:hover {
            background-color: #f1f1f1;
        }

        .input-field {
            display: block;
            width: 100%;
            margin-top: 0.25rem;
            padding: 0.5rem 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            background-color: #fff;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            font-size: 0.875rem;
            line-height: 1.25rem;
            color: #374151;
        }

        .input-field:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.5);
        }

        .btn-secondary {
            background-color: #6b7280;
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-size: 0.875rem;
            line-height: 1.25rem;
            cursor: pointer;
        }

        .btn-secondary:hover {
            background-color: #4b5563;
        }

        .btn-primary {
            background-color: #3b82f6;
            color: #fff;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-size: 0.875rem;
            line-height: 1.25rem;
            cursor: pointer;
        }

        .btn-primary:hover {
            background-color: #2563eb;
        }

        #addEventModal .bg-white,
        #editEventModal .bg-white {
            max-height: 90vh; /* Altura máxima del 90% de la ventana */
            max-width: 90vw; /* Ancho máximo del 90% de la ventana */
            width: 100%; /* Ancho completo para pantallas pequeñas */
            overflow-y: auto; /* Habilitar scroll si el contenido excede */
        }

        @media (min-width: 768px) {
            #addEventModal .bg-white,
            #editEventModal .bg-white {
                max-width: 40vw; /* Ancho máximo del 40% de la ventana en pantallas medianas y grandes */
            }
        }

        #calendar {
            width: 100%; /* Ocupa el ancho completo en pantallas pequeñas */
            height: auto; /* Ajusta la altura automáticamente */
        }

        @media (min-width: 768px) {
            #calendar {
                width: 90%; /* Ocupa el 90% del ancho en pantallas medianas */
                margin: 0 auto; /* Centra el calendario horizontalmente */
            }
        }

        @media (min-width: 1024px) {
            #calendar {
                width: 80%; /* Ocupa el 80% del ancho en pantallas grandes */
            }
        }

        @media (max-width: 420px) {
            #calendar {
                font-size: 0.8rem; /* Reduce el tamaño de fuente para pantallas muy pequeñas */
            }

            .fc-toolbar-title {
                font-size: 1rem; /* Ajusta el tamaño del título del calendario */
            }

            .fc-button {
                padding: 0.25rem 0.5rem; /* Reduce el padding de los botones */
                font-size: 0.75rem; /* Ajusta el tamaño de los botones */
            }
        }
    </style>
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Barra lateral de navegación -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Logo y nombre del sistema -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../dashboard/index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/logoedit.png" alt="logo" class="logo">
                </div>
                <div class="sidebar-brand-text mx-3">SisgeAsic</div>
            </a>
            <!-- Separador -->
            <hr class="sidebar-divider my-0">
            <!-- Enlace al Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="../dashboard/index.php">
                    <i class="fa-solid fa-house-medical"></i>
                    <span>Dashboard</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Encabezado de módulos -->
            <div class="sidebar-heading">Modulos</div>
            <!-- Módulo de Pacientes -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>Pacientes</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="paciente.php">Lista de pacientes</a>
                        <a class="collapse-item" href="agregar_paciente.php">Agregar paciente</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Opciones:</h6>
                        <a class="collapse-item" href="historia_medica_general.php">Historia Medica</a>
                    </div>
                </div>
            </li>
            <!-- Módulo de Médicos -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-user-md" aria-hidden="true"></i>
                    <span>Medicos</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="medico.php">Lista de Medicos</a>
                        
                    </div>
                </div>
            </li>
            <!-- Módulo de Citas -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCitas" aria-expanded="true" aria-controls="collapseCitas">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Citas</span>
                </a>
                <div id="collapseCitas" class="collapse" aria-labelledby="headingCitas" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="gestion_citas.php">Gestión de Citas</a>
                        <a class="collapse-item" href="citas.php">Calendario de Citas</a>
                    </div>
                </div>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Opciones de Administrador -->
            <div class="sidebar-heading">Opciones de Administrador</div>
            <!-- Módulo de Usuarios -->
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fa-solid fa-users"></i>
                    <span>Usuarios</span></a>
            </li>
            <!-- Módulo de Especialidades -->
            <li class="nav-item">
                <a class="nav-link" href="especialidades.php">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Especialidades</span></a>
            </li>
            <!-- Módulo de Estadísticas -->
            <li class="nav-item">
                <a class="nav-link" href="charts.html">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Estadisticas</span></a>
            </li>
            <!-- Módulo de Reportes -->
            <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fa-solid fa-file-medical"></i>
                    <span>Reportes</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider d-none d-md-block">
            <!-- Botón para colapsar la barra lateral -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- Contenido principal -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Barra superior -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Botón para colapsar la barra lateral -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Menú de usuario -->
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Carlos</span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <!-- Opciones del usuario -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Configuración
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Actividad
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Cerrar Sesión
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- Contenedor principal -->
                <div class="container mx-auto p-4">
                    <!-- Título del módulo -->
                    <h1 class="text-2xl font-bold text-gray-800 mb-4">Calendario de Citas</h1>
                    <!-- Contenedor del calendario -->
                    <div id="calendar" class="bg-white rounded-lg shadow-md p-4"></div>
                </div>

                <!-- Modal para agregar citas -->
                <div id="addEventModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden z-50" style="backdrop-filter: blur(5px);">
                    <div class="bg-white rounded-lg shadow-lg w-full max-w-md p-6 relative">
                        <button id="closeModalButton" class="absolute top-3 right-3 text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4 text-center">Agregar Cita</h2>
                        <form id="addEventForm">
                            <div class="mb-4">
                                <label for="titulo" class="block text-sm font-medium text-gray-700">Título</label>
                                <input type="text" id="titulo" name="titulo" class="input-field" placeholder="Ej. Consulta médica" required>
                            </div>
                            <div class="mb-4">
                                <label for="medico" class="block text-sm font-medium text-gray-700">Médico</label>
                                <select id="medico" name="medico" class="input-field" required>
                                    <option value="" disabled selected>Seleccione un médico</option>
                                    <?php foreach ($medicos as $medico): ?>
                                        <option value="<?= $medico['id_medico'] ?>"><?= $medico['pr_nombre'] . ' ' . $medico['pr_apellido'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="paciente" class="block text-sm font-medium text-gray-700">Paciente</label>
                                <input type="text" id="buscar_paciente" class="input-field mb-2" placeholder="Buscar por cédula">
                                <select id="paciente" name="paciente" class="input-field" required>
                                    <option value="" disabled selected>Seleccione un paciente</option>
                                    <?php foreach ($pacientes as $paciente): ?>
                                        <option value="<?= $paciente['cedula'] ?>" data-cedula="<?= $paciente['cedula'] ?>">
                                            <?= $paciente['pr_nombre'] . ' ' . $paciente['pr_apellido'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="especialidad" class="block text-sm font-medium text-gray-700">Especialidad</label>
                                <select id="especialidad" name="especialidad" class="input-field" required>
                                    <option value="" disabled selected>Seleccione una especialidad</option>
                                    <?php foreach ($especialidades as $especialidad): ?>
                                        <option value="<?= $especialidad['id_especialidad'] ?>">
                                            <span class="color-circle" style="background-color: <?= $especialidad['color'] ?>;"></span>
                                            <?= $especialidad['nombre_especialidad'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="fecha_inicio" class="block text-sm font-medium text-gray-700">Fecha de Inicio</label>
                                <input type="datetime-local" id="fecha_inicio" name="fecha_inicio" class="input-field" required>
                            </div>
                            <div class="mb-4">
                                <label for="fecha_fin" class="block text-sm font-medium text-gray-700">Fecha de Fin</label>
                                <input type="datetime-local" id="fecha_fin" name="fecha_fin" class="input-field" required>
                            </div>
                            <div class="flex justify-end space-x-2">
                                <button type="button" id="cancelButton" class="btn-secondary">Cancelar</button>
                                <button type="submit" class="btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Modal para editar citas -->
                <div id="editEventModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden z-50" style="backdrop-filter: blur(5px);">
                    <div class="bg-white rounded-lg shadow-lg w-full max-w-md p-6 relative">
                        <button id="closeEditModalButton" class="absolute top-3 right-3 text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4 text-center">Editar Cita</h2>
                        <form id="editEventForm">
                            <input type="hidden" id="edit_event_id" name="id">
                            <div class="mb-4">
                                <label for="edit_titulo" class="block text-sm font-medium text-gray-700">Título</label>
                                <input type="text" id="edit_titulo" name="titulo" class="input-field" required>
                            </div>
                            <div class="mb-4">
                                <label for="edit_fecha_inicio" class="block text-sm font-medium text-gray-700">Fecha de Inicio</label>
                                <input type="datetime-local" id="edit_fecha_inicio" name="fecha_inicio" class="input-field" required>
                            </div>
                            <div class="mb-4">
                                <label for="edit_fecha_fin" class="block text-sm font-medium text-gray-700">Fecha de Fin</label>
                                <input type="datetime-local" id="edit_fecha_fin" name="fecha_fin" class="input-field" required>
                            </div>
                            <div class="mb-4">
                                <label for="edit_medico" class="block text-sm font-medium text-gray-700">Médico</label>
                                <select id="edit_medico" name="medico" class="input-field" required>
                                    <option value="" disabled selected>Seleccione un médico</option>
                                    <?php foreach ($medicos as $medico): ?>
                                        <option value="<?= $medico['id_medico'] ?>"><?= $medico['pr_nombre'] . ' ' . $medico['pr_apellido'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="edit_paciente" class="block text-sm font-medium text-gray-700">Paciente</label>
                                <!-- Mostrar la cédula del paciente -->
                                <p id="paciente_cedula" class="text-base font-semibold text-gray-800 mb-2"></p>
                                <!-- Mostrar el nombre del paciente como texto no editable -->
                                <p id="paciente_nombre" class="text-base font-semibold text-gray-800"></p>
                            </div>
                            <div class="flex justify-between">
                                <button type="button" id="deleteEventButton" class="btn-secondary">Eliminar</button>
                                <button type="submit" class="btn-primary">Guardar Cambios</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Modal para cerrar sesión -->
            <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="logoutModalLabel">¿Listo para salir?</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">Seleccione "Cerrar Sesión" a continuación para finalizar su sesión actual.</div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                            <a class="btn btn-primary" href="?logout=true">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Scripts necesarios -->
            <script src="../dashboard/vendor/jquery/jquery.min.js"></script> <!-- Biblioteca jQuery para manipulación del DOM y eventos -->
            <script src="../dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script> <!-- Scripts de Bootstrap para componentes interactivos como modales y menús -->
            <script src="../dashboard/vendor/jquery-easing/jquery.easing.min.js"></script> <!-- Plugin para animaciones suaves en desplazamientos -->
            <script src="../dashboard/js/sb-admin-2.min.js"></script> <!-- Script principal para funcionalidades del tema SB Admin 2 -->
            <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script> <!-- Biblioteca FullCalendar para mostrar y gestionar el calendario -->
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    var calendarEl = document.getElementById('calendar');
                    var addEventModal = document.getElementById('addEventModal');
                    var addEventForm = document.getElementById('addEventForm');
                    var cancelButton = document.getElementById('cancelButton');
                    var closeModalButton = document.getElementById('closeModalButton');
                    var editEventModal = document.getElementById('editEventModal');
                    var editEventForm = document.getElementById('editEventForm');
                    var closeEditModalButton = document.getElementById('closeEditModalButton');
                    var deleteEventButton = document.getElementById('deleteEventButton');

                    var calendar = new FullCalendar.Calendar(calendarEl, {
                        locale: 'es',
                        initialView: 'dayGridMonth',
                        headerToolbar: {
                            left: 'prev,next',
                            center: 'title',
                            right: 'dayGridMonth,timeGridWeek,timeGridDay'
                        },
                        buttonText: {
                            today: 'Hoy',
                            month: 'Mes',
                            week: 'Semana',
                            day: 'Día',
                            list: 'Agenda'
                        },
                        events: [
                            <?php foreach ($citas as $cita): ?>
                            {
                                id: '<?= $cita['id'] ?>',
                                title: '<?= $cita['titulo'] ?>',
                                start: '<?= $cita['fecha_inicio'] ?>',
                                end: '<?= $cita['fecha_fin'] ?>',
                                color: '<?= $cita['color'] ?>'
                            },
                            <?php endforeach; ?>
                        ],
                        dateClick: function(info) {
                            addEventModal.classList.remove('hidden');
                            document.getElementById('fecha_inicio').value = info.dateStr + 'T00:00';
                            document.getElementById('fecha_fin').value = info.dateStr + 'T23:59';
                        },
                        eventClick: function(info) {
                            // Mostrar modal de edición
                            editEventModal.classList.remove('hidden');
                            const eventId = info.event.id;

                            if (!eventId) {
                                alert('Error: ID de la cita no válido.');
                                return;
                            }

                            document.getElementById('edit_event_id').value = eventId;

                            // Obtener información adicional del médico y paciente
                            fetch(`../../backend/get_event_details.php?id=${eventId}`)
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        const cita = data.data;

                                        // Cargar datos en el formulario
                                        document.getElementById('edit_titulo').value = cita.titulo;
                                        document.getElementById('edit_fecha_inicio').value = cita.fecha_inicio;
                                        document.getElementById('edit_fecha_fin').value = cita.fecha_fin;
                                        document.getElementById('edit_medico').value = cita.id_medico;

                                        // Mostrar la cédula y el nombre del paciente
                                        const pacienteCedulaField = document.getElementById('paciente_cedula');
                                        const pacienteNombreField = document.getElementById('paciente_nombre');
                                        if (pacienteCedulaField && pacienteNombreField) {
                                            pacienteCedulaField.textContent = `Cédula: ${cita.cedula}`;
                                            pacienteNombreField.textContent = `Nombre: ${cita.paciente_nombre} ${cita.paciente_apellido}`;
                                        }
                                    } else {
                                        alert('Error al cargar los detalles de la cita: ' + (data.message || 'Error desconocido.'));
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    alert('Error al cargar los detalles de la cita. Verifique la consola para más detalles.');
                                });
                        }
                    });

                    calendar.render();

                    cancelButton.addEventListener('click', function () {
                        addEventModal.classList.add('hidden');
                    });

                    closeModalButton.addEventListener('click', function () {
                        addEventModal.classList.add('hidden');
                    });

                    closeEditModalButton.addEventListener('click', function () {
                        editEventModal.classList.add('hidden');
                    });

                    addEventForm.addEventListener('submit', function (e) {
                        e.preventDefault();

                        var formData = new FormData(addEventForm);

                        fetch('../../backend/add_event.php', { 
                            method: 'POST',
                            body: formData
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(`HTTP error! status: ${response.status}`);
                            }
                            return response.json();
                        })
                        .then(data => {
                            if (data.success) {
                                calendar.addEvent({
                                    title: formData.get('titulo'),
                                    start: formData.get('fecha_inicio'),
                                    end: formData.get('fecha_fin'),
                                    color: '#3788d8' // Color predeterminado
                                });

                                addEventModal.classList.add('hidden');
                                addEventForm.reset();
                            } else {
                                alert('Error al guardar la cita: ' + (data.message || 'Error desconocido.'));
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('Error al guardar la cita. Verifique la consola para más detalles.');
                        });
                    });

                    editEventForm.addEventListener('submit', function (e) {
                        e.preventDefault();

                        var formData = new FormData(editEventForm);

                        fetch('../../backend/edit_event.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                var event = calendar.getEventById(formData.get('id'));
                                event.setProp('title', formData.get('titulo'));
                                event.setStart(formData.get('fecha_inicio'));
                                event.setEnd(formData.get('fecha_fin'));
                                editEventModal.classList.add('hidden');
                            } else {
                                alert('Error al actualizar la cita.');
                            }
                        })
                        .catch(error => console.error('Error:', error));
                    });

                    deleteEventButton.addEventListener('click', function () {
                        const eventId = document.getElementById('edit_event_id').value;

                        if (!eventId) {
                            alert('Error: ID de la cita no válido.');
                            return;
                        }

                        if (confirm('¿Está seguro de que desea eliminar esta cita?')) {
                            fetch(`../../backend/delete_event.php?id=${eventId}`, {
                                method: 'DELETE'
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    const event = calendar.getEventById(eventId);
                                    if (event) {
                                        event.remove();
                                    }
                                    editEventModal.classList.add('hidden');
                                    alert('Cita eliminada correctamente.');
                                } else {
                                    alert('Error al eliminar la cita: ' + (data.message || 'Error desconocido.'));
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                alert('Error al eliminar la cita. Verifique la consola para más detalles.');
                            });
                        }
                    });

                    const buscarPacienteInput = document.getElementById('buscar_paciente');
                    const pacienteSelect = document.getElementById('paciente');
                    const medicoSelect = document.getElementById('medico');
                    const especialidadSelect = document.getElementById('especialidad');

                    // Filtrar y seleccionar automáticamente el paciente por cédula
                    buscarPacienteInput.addEventListener('input', function () {
                        const filtro = buscarPacienteInput.value.toLowerCase();
                        let encontrado = false;

                        Array.from(pacienteSelect.options).forEach(option => {
                            const cedula = option.getAttribute('data-cedula') || '';
                            if (cedula.includes(filtro)) {
                                option.style.display = '';
                                if (cedula === filtro) {
                                    pacienteSelect.value = option.value;
                                    encontrado = true;
                                }
                            } else {
                                option.style.display = 'none';
                            }
                        });

                        if (!encontrado) {
                            pacienteSelect.value = '';
                        }
                    });

                    // Cargar especialidades relacionadas con el médico seleccionado
                    medicoSelect.addEventListener('change', function () {
                        const medicoId = medicoSelect.value;

                        // Limpiar las opciones actuales
                        especialidadSelect.innerHTML = '<option value="" disabled selected>Seleccione una especialidad</option>';

                        // Obtener especialidades relacionadas con el médico
                        fetch(`../../backend/get_especialidades.php?medico_id=${medicoId}`)
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Error al obtener las especialidades');
                                }
                                return response.json();
                            })
                            .then(data => {
                                if (data.length > 0) {
                                    data.forEach(especialidad => {
                                        const option = document.createElement('option');
                                        option.value = especialidad.id_especialidad;
                                        option.textContent = especialidad.nombre_especialidad; // Usar 'nombre_especialidad' según la estructura
                                        especialidadSelect.appendChild(option);
                                    });
                                } else {
                                    const noOption = document.createElement('option');
                                    noOption.value = '';
                                    noOption.textContent = 'No hay especialidades disponibles';
                                    especialidadSelect.appendChild(noOption);
                                }
                            })
                            .catch(error => {
                                console.error('Error al cargar las especialidades:', error);
                                alert('Error al cargar las especialidades. Verifique la consola para más detalles.');
                            });
                    });
                });
            </script>
        </div>
    </div>
</body>

</html>