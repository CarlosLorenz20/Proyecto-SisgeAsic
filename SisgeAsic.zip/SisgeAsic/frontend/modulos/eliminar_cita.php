<?php
header('Content-Type: application/json');

// Conexión a la base de datos
$conn = pg_connect("host=localhost dbname=bd_asic user=postgres password=30429913");

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos.']);
    exit();
}

if (isset($_GET['id'])) {
    $id = pg_escape_string($conn, $_GET['id']);
    $query = "DELETE FROM citas WHERE id = '$id'";
    $result = pg_query($conn, $query);

    if ($result) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al eliminar la cita.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'ID no proporcionado.']);
}

pg_close($conn);
?>
