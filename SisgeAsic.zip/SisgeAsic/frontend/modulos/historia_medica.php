<?php
// Inicia la sesión para mantener el estado del usuario
session_start();

// Verifica si se solicita cerrar sesión
if (isset($_GET['logout'])) {
    // Destruye la sesión y redirige al login
    session_destroy();
    header('Location: ../login/login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Configuración básica del documento -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Carga de iconos y estilos -->
    <script src="https://kit.fontawesome.com/7a4cab1fbd.js" crossorigin="anonymous"></script>
    <title>SisgeAsic - Historia Médica</title>
    <link rel="icon" type="image/png" sizes="96x96" href="../img/logo2.png">
    <link href="../dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../dashboard/css/sb-admin-2.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Barra lateral de navegación -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Logo y nombre del sistema -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../dashboard/index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/logoedit.png" alt="logo" class="logo">
                </div>
                <div class="sidebar-brand-text mx-3">SisgeAsic</div>
            </a>
            <!-- Separador -->
            <hr class="sidebar-divider my-0">
            <!-- Enlace al Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="../dashboard/index.php">
                    <i class="fa-solid fa-house-medical"></i>
                    <span>Dashboard</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Encabezado de módulos -->
            <div class="sidebar-heading">Modulos</div>
            <!-- Módulo de Pacientes -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>Pacientes</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="paciente.php">Lista de pacientes</a>
                        <a class="collapse-item" href="agregar_paciente.php">Agregar paciente</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Opciones:</h6>
                        <a class="collapse-item" href="historia_medica.php">Historia Medica</a>
                    </div>
                </div>
            </li>
            <!-- Módulo de Médicos -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-user-md" aria-hidden="true"></i>
                    <span>Medicos</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="medico.php">Lista de Medicos</a>
                    </div>
                </div>
            </li>
            <!-- Módulo de Citas -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCitas" aria-expanded="true" aria-controls="collapseCitas">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Citas</span>
                </a>
                <div id="collapseCitas" class="collapse" aria-labelledby="headingCitas" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="#">Gestión de Citas</a>
                        <a class="collapse-item" href="../modulos/citas.php">Calendario de Citas</a>
                    </div>
                </div>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Opciones de Administrador -->
            <div class="sidebar-heading">Opciones de Administrador</div>
            <!-- Módulo de Usuarios -->
            <li class="nav-item">
                <a class="nav-link" href="usuarios.php">
                    <i class="fa-solid fa-users"></i>
                    <span>Usuarios</span></a>
            </li>
            <!-- Módulo de Especialidades -->
            <li class="nav-item">
                <a class="nav-link" href="especialidades.php">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Especialidades</span></a>
            </li>
            <!-- Módulo de Estadísticas -->
            <li class="nav-item">
                <a class="nav-link" href="charts.html">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Estadisticas</span></a>
            </li>
            <!-- Módulo de Reportes -->
            <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fa-solid fa-file-medical"></i>
                    <span>Reportes</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider d-none d-md-block">
            <!-- Botón para colapsar la barra lateral -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- Contenido principal -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Barra superior -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Botón para colapsar la barra lateral -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Menú de usuario -->
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Carlos</span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <!-- Opciones del usuario -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Configuración
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Actividad
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Cerrar Sesión
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- Contenedor principal -->
                <div class="container-fluid">
                    <!-- Contenido específico de Historia Médica -->
                    <h1 class="h3 mb-4 text-gray-800">Historia Médica</h1>
                    <form action="procesar_historia_medica.php" method="POST">
                        <!-- Información del paciente -->
                        <table class="table table-bordered">
                            <tr>
                                <td colspan="2"><strong>Centro Asistencial:</strong> <input type="text" name="centro_asistencial" class="form-control"></td>
                                <td><strong>Fecha de Elaboración:</strong> <input type="date" name="fecha_elaboracion" class="form-control"></td>
                            </tr>
                            <tr>
                                <td><strong>Apellido y Nombre del Paciente:</strong> <input type="text" name="nombre_paciente" class="form-control"></td>
                                <td><strong>Historia N°:</strong> <input type="text" name="historia_numero" class="form-control"></td>
                                <td><strong>Cédula de Identidad N°:</strong> <input type="text" name="cedula" class="form-control"></td>
                            </tr>
                            <tr>
                                <td><strong>Edad:</strong> <input type="number" name="edad" class="form-control"></td>
                                <td><strong>Sexo:</strong>
                                    <select name="sexo" class="form-control">
                                        <option value="F">F</option>
                                        <option value="M">M</option>
                                    </select>
                                </td>
                                <td><strong>Estado Civil:</strong>
                                    <select name="estado_civil" class="form-control">
                                        <option value="Soltero">Soltero</option>
                                        <option value="Casado">Casado</option>
                                        <option value="Viudo">Viudo</option>
                                        <option value="Divorciado">Divorciado</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Ocupación:</strong> <input type="text" name="ocupacion" class="form-control"></td>
                                <td colspan="2"><strong>Teléfono:</strong> <input type="text" name="telefono" class="form-control"></td>
                            </tr>
                            <tr>
                                <td colspan="3"><strong>Dirección:</strong> <textarea name="direccion" class="form-control"></textarea></td>
                            </tr>
                        </table>

                        <!-- Motivo de consulta -->
                        <div class="form-group">
                            <label><strong>Motivo de Consulta:</strong></label>
                            <textarea name="motivo_consulta" class="form-control" rows="3"></textarea>
                        </div>

                        <!-- Enfermedad actual -->
                        <div class="form-group">
                            <label><strong>Enfermedad Actual:</strong></label>
                            <textarea name="enfermedad_actual" class="form-control" rows="3"></textarea>
                        </div>

                        <!-- Antecedentes personales -->
                        <div class="form-group">
                            <label><strong>Antecedentes Personales:</strong></label>
                            <textarea name="antecedentes_personales" class="form-control" rows="3"></textarea>
                        </div>

                        <!-- Antecedentes familiares -->
                        <div class="form-group">
                            <label><strong>Antecedentes Familiares:</strong></label>
                            <textarea name="antecedentes_familiares" class="form-control" rows="3"></textarea>
                        </div>

                        <!-- Examen funcional -->
                        <h4 class="mt-4">Examen Funcional</h4>
                        <table class="table table-bordered">
                            <tr>
                                <td><strong>Cabeza:</strong></td>
                                <td><textarea name="cabeza" class="form-control" rows="2"></textarea></td>
                            </tr>
                            <tr>
                                <td><strong>Ojos-Oídos-Nariz-Garganta:</strong></td>
                                <td><textarea name="ojos_oidos_nariz_garganta" class="form-control" rows="2"></textarea></td>
                            </tr>
                            <tr>
                                <td><strong>Respiratorio:</strong></td>
                                <td><textarea name="respiratorio" class="form-control" rows="2"></textarea></td>
                            </tr>
                            <tr>
                                <td><strong>Corazón:</strong></td>
                                <td><textarea name="corazon" class="form-control" rows="2"></textarea></td>
                            </tr>
                            <tr>
                                <td><strong>Gastro-Intestinal:</strong></td>
                                <td><textarea name="gastrointestinal" class="form-control" rows="2"></textarea></td>
                            </tr>
                            <tr>
                                <td><strong>Genito-Urinario:</strong></td>
                                <td><textarea name="genitourinario" class="form-control" rows="2"></textarea></td>
                            </tr>
                        </table>

                        <!-- Firma -->
                        <div class="form-group">
                            <label><strong>Elaborado por:</strong></label>
                            <input type="text" name="elaborado_por" class="form-control">
                        </div>
                        <div class="form-group">
                            <label><strong>Cargo:</strong></label>
                            <input type="text" name="cargo" class="form-control">
                        </div>
                        <div class="form-group">
                            <label><strong>Firma:</strong></label>
                            <input type="text" name="firma" class="form-control">
                        </div>

                        <!-- Botón de envío -->
                        <button type="submit" class="btn btn-primary">Guardar Historia Médica</button>
                    </form>
                </div>
            </div>
            <!-- Modal para cerrar sesión -->
            <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="logoutModalLabel">¿Listo para salir?</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">Seleccione "Cerrar Sesión" a continuación para finalizar su sesión actual.</div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                            <a class="btn btn-primary" href="?logout=true">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Scripts necesarios -->
            <script src="../dashboard/vendor/jquery/jquery.min.js"></script>
            <script src="../dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
            <script src="../dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>
            <script src="../dashboard/js/sb-admin-2.min.js"></script>
        </div>
    </div>
</body>

</html>
