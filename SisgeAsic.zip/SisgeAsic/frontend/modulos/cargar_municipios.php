<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432"; // Puerto por defecto de PostgreSQL
$dbname = "bd_asic"; // Cambia esto por el nombre correcto de tu base de datos
$user = "postgres"; // Usuario de PostgreSQL
$password = "30429913"; // Contraseña del usuario

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";

$conn = pg_connect($conn_string);

// Manejo de errores para la conexión
if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// Verificar si se recibió el parámetro estado_id
if (isset($_GET['estado_id'])) {
    $estado_id = $_GET['estado_id'];

    // Consulta para obtener los municipios del estado seleccionado
    $query = "SELECT id_municipio, nombre FROM municipio WHERE estado_id = $1";
    $result = pg_query_params($conn, $query, array($estado_id));

    if ($result) {
        $municipios = [];
        while ($row = pg_fetch_assoc($result)) {
            $municipios[] = $row;
        }

        // Devolver los municipios en formato JSON
        header('Content-Type: application/json');
        echo json_encode(['municipios' => $municipios]);
    } else {
        // Manejo de errores en la consulta
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Error al obtener los municipios']);
    }
} else {
    // Manejo de errores si no se recibe el parámetro estado_id
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Parámetro estado_id no proporcionado']);
}

// Cerrar la conexión a la base de datos
pg_close($conn);
?>