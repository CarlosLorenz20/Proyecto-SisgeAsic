<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432"; // Puerto por defecto de PostgreSQL
$dbname = "bd_asic"; // Cambia esto por el nombre correcto de tu base de datos
$user = "postgres"; // Usuario de PostgreSQL
$password = "30429913"; // Contraseña del usuario

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";

$conn = pg_connect($conn_string);

// Manejo de errores para la conexión
if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// Verificar si se recibió el ID del municipio
if (isset($_GET['municipio_id'])) {
    $municipio_id = $_GET['municipio_id'];

    // Consulta para obtener las parroquias del municipio
    $query = "SELECT id_parroquia, nombre FROM parroquia WHERE municipio_id = $1";
    $result = pg_query_params($conn, $query, array($municipio_id));

    if ($result) {
        $parroquias = [];
        while ($row = pg_fetch_assoc($result)) {
            $parroquias[] = $row;
        }

        // Devolver las parroquias en formato JSON
        header('Content-Type: application/json');
        echo json_encode(['parroquias' => $parroquias]);
    } else {
        // Manejo de errores en la consulta
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Error al obtener las parroquias']);
    }
} else {
    // Manejo de errores si no se recibió el ID del municipio
    header('Content-Type: application/json');
    echo json_encode(['error' => 'ID del municipio no proporcionado']);
}

// Cerrar la conexión a la base de datos
pg_close($conn);
?>