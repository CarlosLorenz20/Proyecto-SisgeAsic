<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Configuración de la base de datos
$host = "localhost";
$port = "5432";
$dbname = "bd_asic";
$user = "postgres";
$password = "30429913";

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";
$conn = pg_connect($conn_string);

// Verificar conexión
if (!$conn) {
    echo json_encode(['success' => false, 'error' => 'Error de conexión a la base de datos']);
    exit();
}

// Leer datos enviados en la solicitud
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['cedula']) || empty($data['cedula'])) {
    echo json_encode(['success' => false, 'error' => 'Cédula no proporcionada o está vacía']);
    exit();
}

$cedula = $data['cedula'];

// Validar que el paciente exista antes de eliminar
$check_query = "SELECT 1 FROM paciente WHERE cedula = $1";
$check_result = pg_query_params($conn, $check_query, [$cedula]);

if (!$check_result || pg_num_rows($check_result) === 0) {
    echo json_encode(['success' => false, 'error' => 'El paciente con la cédula proporcionada no existe']);
    pg_close($conn);
    exit();
}

// Eliminar paciente de la base de datos
$query = "DELETE FROM paciente WHERE cedula = $1";
$result = pg_query_params($conn, $query, [$cedula]);

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Error al eliminar el paciente: ' . pg_last_error($conn)]);
}

// Cerrar conexión
pg_close($conn);
?>
