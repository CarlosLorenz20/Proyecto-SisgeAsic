<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432"; // Puerto por defecto de PostgreSQL
$dbname = "bd_asic"; // Cambia esto por el nombre correcto de tu base de datos
$user = "postgres"; // Usuario de PostgreSQL
$password = "30429913"; // Contraseña del usuario

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";

$conn = pg_connect($conn_string);

// Manejo de errores para la conexión
if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// Consulta para obtener los estados
$query = "SELECT id_estado, nombre FROM estado";
$result = pg_query($conn, $query);

if (!$result) {
    die("Error en la consulta: " . pg_last_error($conn));
}

$estados = [];
while ($row = pg_fetch_assoc($result)) {
    $estados[] = $row;
}

// Devolver los estados en formato JSON
header('Content-Type: application/json');
echo json_encode(['estados' => $estados]);

// Cerrar la conexión
pg_close($conn);
?>