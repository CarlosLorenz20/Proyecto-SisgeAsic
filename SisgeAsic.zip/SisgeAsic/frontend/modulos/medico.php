<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inicia la sesión para mantener el estado del usuario
session_start();

// Verifica si se solicita cerrar sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ../login/login.php');
    exit();
}

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432";
$dbname = "bd_asic";
$user = "postgres";
$password = "30429913";

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";
$conn = pg_connect($conn_string);

if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Procesar el formulario de agregar médico
    if (isset($_POST['pr_nombre'])) {
        $pr_nombre = $_POST['pr_nombre'];
        $sdo_nombre = $_POST['sdo_nombre'];
        $pr_apellido = $_POST['pr_apellido'];
        $sdo_apellido = $_POST['sdo_apellido'];
        $id_especialidad = $_POST['id_especialidad'];

        // Consulta para insertar el médico (sin incluir id_medico)
        $insert_query = "INSERT INTO medico (pr_nombre, sdo_nombre, pr_apellido, sdo_apellido, id_especialidad) 
                         VALUES ($1, $2, $3, $4, $5)";
        $insert_result = pg_query_params($conn, $insert_query, [
            $pr_nombre, 
            $sdo_nombre, 
            $pr_apellido, 
            $sdo_apellido, 
            $id_especialidad
        ]);

        if (!$insert_result) {
            echo "<script>alert('Error al agregar el médico: " . pg_last_error($conn) . "');</script>";
        } else {
            echo "<script>alert('Médico agregado exitosamente');</script>";
        }
    }

    // Procesar la eliminación de un médico
    if (isset($_POST['delete_medico'])) {
        $id_medico = $_POST['id_medico'];

        $delete_query = "DELETE FROM medico WHERE id_medico = $1";
        $delete_result = pg_query_params($conn, $delete_query, [$id_medico]);

        if (!$delete_result) {
            echo "<script>alert('Error al eliminar el médico: " . pg_last_error($conn) . "');</script>";
        } else {
            echo "<script>alert('Médico eliminado exitosamente');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://kit.fontawesome.com/7a4cab1fbd.js" crossorigin="anonymous"></script>
    <title>SisgeAsic - Médicos</title>
    <link rel="icon" type="image/png" sizes="96x96" href="../img/logo2.png">
    <link href="../dashboard/../dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="../dashboard/css/sb-admin-2.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Barra lateral de navegación -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Logo y nombre del sistema -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../dashboard/index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/logoedit.png" alt="logo" class="logo">
                </div>
                <div class="sidebar-brand-text mx-3">SisgeAsic</div>
            </a>
            <!-- Separador -->
            <hr class="sidebar-divider my-0">
            <!-- Enlace al Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="../dashboard/index.php">
                    <i class="fa-solid fa-house-medical"></i>
                    <span>Dashboard</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Encabezado de módulos -->
            <div class="sidebar-heading">Modulos</div>
            <!-- Módulo de Pacientes -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>Pacientes</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="paciente.php">Lista de pacientes</a>
                        <a class="collapse-item" href="agregar_paciente.php">Agregar paciente</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Opciones:</h6>
                        <a class="collapse-item" href="historia_medica_general.php">Historia Medica</a>
                    </div>
                </div>
            </li>
            <!-- Módulo de Médicos -->
            <li class="nav-item active">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-user-md" aria-hidden="true"></i>
                    <span>Medicos</span>
                </a>
                <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="#">Lista de Medicos</a>
                        
                    </div>
                </div>
            </li>
            <!-- Módulo de Citas -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCitas" aria-expanded="true" aria-controls="collapseCitas">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Citas</span>
                </a>
                <div id="collapseCitas" class="collapse" aria-labelledby="headingCitas" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="gestion_citas.php">Gestión de Citas</a>
                        <a class="collapse-item" href="../modulos/citas.php">Calendario de Citas</a>
                    </div>
                </div>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Opciones de Administrador -->
            <div class="sidebar-heading">Opciones de Administrador</div>
            <!-- Módulo de Usuarios -->
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fa-solid fa-users"></i>
                    <span>Usuarios</span></a>
            </li>
            <!-- Módulo de Especialidades -->
            <li class="nav-item">
                <a class="nav-link" href="especialidades.php">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Especialidades</span></a>
            </li>
            <!-- Módulo de Estadísticas -->
            <li class="nav-item">
                <a class="nav-link" href="charts.html">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Estadisticas</span></a>
            </li>
            <!-- Módulo de Reportes -->
            <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fa-solid fa-file-medical"></i>
                    <span>Reportes</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider d-none d-md-block">
            <!-- Botón para colapsar la barra lateral -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- Contenido principal -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Barra superior -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Botón para colapsar la barra lateral -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Menú de usuario -->
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Carlos</span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <!-- Opciones del usuario -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Configuración
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Actividad
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Cerrar Sesión
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- Contenedor principal -->
                <div class="container-fluid">
                    <!-- CRUD de médicos -->
                    <h1 class="h3 mb-4 text-gray-800">Gestión de Médicos</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">Lista de Médicos</h6>
                            <button class="btn btn-primary btn-sm" id="openAddMedicoModal">Agregar Médico</button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Médico</th>
                                            <th>Especialidad</th>
                                            <th>Primer Nombre</th>
                                            <th>Segundo Nombre</th>
                                            <th>Primer Apellido</th>
                                            <th>Segundo Apellido</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = "SELECT m.id_medico, e.nombre_especialidad, m.pr_nombre, m.sdo_nombre, m.pr_apellido, m.sdo_apellido, m.id_especialidad 
                                                  FROM medico m
                                                  JOIN especialidad e ON m.id_especialidad = e.id_especialidad";
                                        $result = pg_query($conn, $query);

                                        if (!$result) {
                                            die("Error en la consulta: " . pg_last_error($conn));
                                        }

                                        if (pg_num_rows($result) > 0) {
                                            while ($row = pg_fetch_assoc($result)) {
                                                echo "<tr>";
                                                echo "<td>" . (isset($row['id_medico']) ? $row['id_medico'] : 'N/A') . "</td>";
                                                echo "<td>" . (isset($row['nombre_especialidad']) ? $row['nombre_especialidad'] : 'N/A') . "</td>";
                                                echo "<td>" . (isset($row['pr_nombre']) ? $row['pr_nombre'] : 'N/A') . "</td>";
                                                echo "<td>" . (isset($row['sdo_nombre']) ? $row['sdo_nombre'] : 'N/A') . "</td>";
                                                echo "<td>" . (isset($row['pr_apellido']) ? $row['pr_apellido'] : 'N/A') . "</td>";
                                                echo "<td>" . (isset($row['sdo_apellido']) ? $row['sdo_apellido'] : 'N/A') . "</td>";
                                                echo "<td>
                                                    <button class='btn btn-warning btn-sm' data-toggle='modal' data-target='#editModal{$row['id_medico']}'>Editar</button>
                                                    <form method='POST' style='display:inline;' onsubmit='return confirm(\"¿Está seguro de que desea eliminar este médico?\");'>
                                                        <input type='hidden' name='id_medico' value='{$row['id_medico']}'>
                                                        <button type='submit' name='delete_medico' class='btn btn-danger btn-sm'>Eliminar</button>
                                                    </form>
                                                </td>";
                                                echo "</tr>";

                                                // Modal para editar médico
                                                echo "
                                                <div class='modal fade' id='editModal{$row['id_medico']}' tabindex='-1' role='dialog' aria-labelledby='editModalLabel{$row['id_medico']}' aria-hidden='true'>
                                                    <div class='modal-dialog' role='document'>
                                                        <div class='modal-content'>
                                                            <div class='modal-header'>
                                                                <h5 class='modal-title' id='editModalLabel{$row['id_medico']}'>Editar Médico</h5>
                                                                <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                                                    <span aria-hidden='true'>&times;</span>
                                                                </button>
                                                            </div>
                                                            <form action='guardar_medico.php' method='POST'>
                                                                <div class='modal-body'>
                                                                    <input type='hidden' name='id_medico' value='{$row['id_medico']}'>
                                                                    <div class='form-group'>
                                                                        <label for='id_especialidad'>Especialidad</label>
                                                                        <select class='form-control' name='id_especialidad' required>";
                                                $especialidades_query = "SELECT id_especialidad, nombre_especialidad FROM especialidad";
                                                $especialidades_result = pg_query($conn, $especialidades_query);
                                                if ($especialidades_result) {
                                                    while ($especialidad = pg_fetch_assoc($especialidades_result)) {
                                                        $selected = ($especialidad['id_especialidad'] == $row['id_especialidad']) ? "selected" : "";
                                                        echo "<option value='{$especialidad['id_especialidad']}' $selected>{$especialidad['nombre_especialidad']}</option>";
                                                    }
                                                }
                                                echo "              </select>
                                                                    </div>
                                                                    <div class='form-group'>
                                                                        <label for='pr_nombre'>Primer Nombre</label>
                                                                        <input type='text' class='form-control' name='pr_nombre' value='" . (isset($row['pr_nombre']) ? $row['pr_nombre'] : '') . "' required>
                                                                    </div>
                                                                    <div class='form-group'>
                                                                        <label for='sg_nombre'>Segundo Nombre</label>
                                                                        <input type='text' class='form-control' name='sg_nombre' value='" . (isset($row['sdo_nombre']) ? $row['sdo_nombre'] : '') . "'>
                                                                    </div>
                                                                    <div class='form-group'>
                                                                        <label for='pr_apellido'>Primer Apellido</label>
                                                                        <input type='text' class='form-control' name='pr_apellido' value='" . (isset($row['pr_apellido']) ? $row['pr_apellido'] : '') . "' required>
                                                                    </div>
                                                                    <div class='form-group'>
                                                                        <label for='sg_apellido'>Segundo Apellido</label>
                                                                        <input type='text' class='form-control' name='sg_apellido' value='" . (isset($row['sdo_apellido']) ? $row['sdo_apellido'] : '') . "'>
                                                                    </div>
                                                                </div>
                                                                <div class='modal-footer'>
                                                                    <button type='button' class='btn btn-secondary' data-dismiss='modal'>Cancelar</button>
                                                                    <button type='submit' class='btn btn-primary'>Guardar Cambios</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='7' class='text-center'>No hay médicos registrados</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Contenedor para la modal -->
                    <div id="addMedicoModalContainer"></div>

                    <script>
                        // Función para desenfocar el fondo al abrir la modal
                        function toggleBlurBackground(isBlurred) {
                            const contentWrapper = document.getElementById('content-wrapper');
                            if (isBlurred) {
                                contentWrapper.classList.add('blur-background');
                            } else {
                                contentWrapper.classList.remove('blur-background');
                            }
                        }

                        document.getElementById('openAddMedicoModal').addEventListener('click', function () {
                            toggleBlurBackground(true);
                            const modalHTML = `
                                <div class="modal fade show" id="addMedicoModal" tabindex="-1" role="dialog" aria-labelledby="addMedicoModalLabel" aria-hidden="true" style="display: block; background: rgba(0, 0, 0, 0.5);">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="addMedicoModalLabel">Agregar Médico</h5>
                                                <button type="button" class="close" id="closeAddMedicoModal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <form method="POST" action="medico.php">
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for="pr_nombre">Primer Nombre</label>
                                                        <input type="text" class="form-control" id="pr_nombre" name="pr_nombre" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="sdo_nombre">Segundo Nombre</label>
                                                        <input type="text" class="form-control" id="sdo_nombre" name="sdo_nombre">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="pr_apellido">Primer Apellido</label>
                                                        <input type="text" class="form-control" id="pr_apellido" name="pr_apellido" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="sdo_apellido">Segundo Apellido</label>
                                                        <input type="text" class="form-control" id="sdo_apellido" name="sdo_apellido">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="id_especialidad">Especialidad</label>
                                                        <select class="form-control" id="id_especialidad" name="id_especialidad" required>
                                                            <option value="" disabled selected>Seleccione</option>
                                                            <?php
                                                            $especialidades_query = "SELECT id_especialidad, nombre_especialidad FROM especialidad";
                                                            $especialidades_result = pg_query($conn, $especialidades_query);
                                                            if ($especialidades_result) {
                                                                while ($especialidad = pg_fetch_assoc($especialidades_result)) {
                                                                    echo "<option value='{$especialidad['id_especialidad']}'>{$especialidad['nombre_especialidad']}</option>";
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" id="cancelAddMedicoModal">Cancelar</button>
                                                    <button type="submit" class="btn btn-primary">Agregar</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            `;
                            document.getElementById('addMedicoModalContainer').innerHTML = modalHTML;

                            // Cerrar la modal y quitar el desenfoque
                            document.getElementById('closeAddMedicoModal').addEventListener('click', closeModal);
                            document.getElementById('cancelAddMedicoModal').addEventListener('click', closeModal);

                            function closeModal() {
                                toggleBlurBackground(false);
                                document.getElementById('addMedicoModalContainer').innerHTML = '';
                            }
                        });

                        // Aplicar la clase de desenfoque al abrir cualquier modal
                        document.addEventListener('DOMContentLoaded', function () {
                            const body = document.body;

                            // Detectar cuando se abre una modal
                            $(document).on('show.bs.modal', function () {
                                body.classList.add('modal-open');
                                document.getElementById('wrapper').classList.add('blur-background');
                            });

                            // Detectar cuando se cierra una modal
                            $(document).on('hidden.bs.modal', function () {
                                body.classList.remove('modal-open');
                                document.getElementById('wrapper').classList.remove('blur-background');
                            });
                        });
                    </script>
                </div>
            </div>
            <!-- Modal para cerrar sesión -->
            <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="logoutModalLabel">¿Listo para salir?</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">Seleccione "Cerrar Sesión" a continuación para finalizar su sesión actual.</div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                            <a class="btn btn-primary" href="?logout=true">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Scripts necesarios -->
            <script src="../dashboard/vendor/jquery/jquery.min.js"></script>
            <script src="../dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
            <script src="../dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>
            <script src="../dashboard/js/sb-admin-2.min.js"></script>
        </div>
    </div>
</body>

</html>