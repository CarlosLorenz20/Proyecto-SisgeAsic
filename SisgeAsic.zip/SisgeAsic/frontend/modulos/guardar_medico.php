<?php
// Conexión a la base de datos
$host = "localhost";
$port = "5432";
$dbname = "bd_asic";
$user = "postgres";
$password = "30429913";

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";
$conn = pg_connect($conn_string);

if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// Obtener datos del formulario
$id_medico = $_POST['id_medico'];
$id_especialidad = $_POST['id_especialidad'];
$pr_nombre = $_POST['pr_nombre'];
$sg_nombre = $_POST['sg_nombre'];
$pr_apellido = $_POST['pr_apellido'];
$sg_apellido = $_POST['sg_apellido'];

// Actualizar datos del médico
$query = "UPDATE medico 
          SET id_especialidad = $1, pr_nombre = $2, sdo_nombre = $3, pr_apellido = $4, sdo_apellido = $5 
          WHERE id_medico = $6";
$result = pg_query_params($conn, $query, [$id_especialidad, $pr_nombre, $sg_nombre, $pr_apellido, $sg_apellido, $id_medico]);

if ($result) {
    header("Location: medico.php");
} else {
    echo "Error al actualizar el médico: " . pg_last_error($conn);
}

pg_close($conn);
?>
