<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inicia la sesión para mantener el estado del usuario
session_start();

// Verifica si se solicita cerrar sesión
if (isset($_GET['logout'])) {
    // Destruye la sesión y redirige al login
    session_destroy();
    header('Location: ../login/login.php');
    exit();
}

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432"; // Puerto por defecto de PostgreSQL
$dbname = "bd_asic"; // Cambia esto por el nombre correcto de tu base de datos
$user = "postgres"; // Usuario de PostgreSQL
$password = "30429913"; // Contraseña del usuario

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";

$conn = pg_connect($conn_string);

// Manejo de errores para la conexión
if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// Consulta para obtener todos los pacientes con las relaciones correctas
$query = "
    SELECT 
        p.*, 
        e.nombre AS estado_nombre, 
        m.nombre AS municipio_nombre, 
        pa.nombre AS parroquia_nombre
    FROM paciente p
    LEFT JOIN estado e ON p.id_estado = e.id_estado
    LEFT JOIN municipio m ON p.id_municipio = m.id_municipio AND m.estado_id = e.id_estado
    LEFT JOIN parroquia pa ON p.id_parroquia = pa.id_parroquia AND pa.municipio_id = m.id_municipio
    ORDER BY p.cedula ASC
";
$result = pg_query($conn, $query);

if (!$result) {
    die("Error en la consulta: " . pg_last_error($conn));
}

$pacientes = [];
while ($row = pg_fetch_assoc($result)) {
    $pacientes[] = $row;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Configuración básica del documento -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Carga de iconos y estilos -->
    <script src="https://kit.fontawesome.com/7a4cab1fbd.js" crossorigin="anonymous"></script>
    <title>SisgeAsic - Pacientes</title>
    <link rel="icon" type="image/png" sizes="96x96" href="  ../img/logo2.png">
    <link href="../dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../dashboard/css/sb-admin-2.css" rel="stylesheet">
    <style>
        /* Asegurar que la tabla sea completamente responsive */
        .table-responsive {
            overflow-x: auto;
        }

        /* Estilo para las celdas de la tabla */
        table.table td, table.table th {
            white-space: nowrap; /* Evitar que el texto se divida en varias líneas */
            overflow: hidden; /* Ocultar el contenido que exceda el ancho */
            text-overflow: ellipsis; /* Mostrar puntos suspensivos si el texto es demasiado largo */
            max-width: 200px; /* Establecer un ancho máximo para las celdas */
        }

        /* Estilo para la columna de dirección */
        table.table td.direccion {
            white-space: normal; /* Permitir que la dirección se divida en varias líneas */
            word-wrap: break-word; /* Dividir palabras largas si es necesario */
            max-width: 300px; /* Establecer un ancho máximo para la dirección */
        }

        .custom-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .custom-modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            border-radius: 5px;
        }

        .custom-modal-close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .custom-modal-close:hover,
        .custom-modal-close:focus {
            color: black;
            text-decoration: none;
        }

        /* Asegurar que los íconos dentro de los botones sean visibles */
        .btn i {
            margin-right: 0 !important; /* Forzar eliminación de margen adicional */
            font-size: 1rem !important; /* Forzar el tamaño del ícono */
            display: inline-block !important; /* Asegurar que se muestren como bloque en línea */
        }

        /* Ajustar el ancho y altura de los botones para que se adapten a los íconos */
        .btn {
            padding: 0.375rem !important; /* Reducir el padding para que los botones sean compactos */
            display: inline-flex !important; /* Asegurar que los íconos se alineen correctamente */
            align-items: center !important; /* Centrar verticalmente los íconos */
            justify-content: center !important; /* Centrar horizontalmente los íconos */
        }

        /* Evitar que estilos externos oculten los botones */
        .btn {
            visibility: visible !important;
            opacity: 1 !important;
        }
    </style>
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Barra lateral de navegación -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Logo y nombre del sistema -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../dashboard/index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/logoedit.png" alt="logo" class="logo">
                </div>
                <div class="sidebar-brand-text mx-3">SisgeAsic</div>
            </a>
            <!-- Separador -->
            <hr class="sidebar-divider my-0">
            <!-- Enlace al Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="../dashboard/index.php">
                    <i class="fa-solid fa-house-medical"></i>
                    <span>Dashboard</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Encabezado de módulos -->
            <div class="sidebar-heading">Modulos</div>
            <!-- Módulo de Pacientes -->
            <li class="nav-item active">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>Pacientes</span>
                </a>
                <div id="collapsePages" class="collapse show" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="paciente.php">Lista de pacientes</a>
                        <a class="collapse-item" href="agregar_paciente.php">Agregar paciente</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Opciones:</h6>
                        <a class="collapse-item" href="historia_medica_general.php">Historia Medica</a>
                    </div>
                </div>
            </li>
            <!-- Módulo de Médicos -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-user-md" aria-hidden="true"></i>
                    <span>Medicos</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="medico.php">Lista de Medicos</a>
                        
                    </div>
                </div>
            </li>
            <!-- Módulo de Citas -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCitas" aria-expanded="true" aria-controls="collapseCitas">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Citas</span>
                </a>
                <div id="collapseCitas" class="collapse" aria-labelledby="headingCitas" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="gestion_citas.php">Gestión de Citas</a>
                        <a class="collapse-item" href="citas.php">Calendario de Citas</a>
                    </div>
                </div>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Opciones de Administrador -->
            <div class="sidebar-heading">Opciones de Administrador</div>
            <!-- Módulo de Usuarios -->
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fa-solid fa-users"></i>
                    <span>Usuarios</span></a>
            </li>
            <!-- Módulo de Especialidades -->
            <li class="nav-item">
                <a class="nav-link" href="especialidades.php">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Especialidades</span></a>
            </li>
            <!-- Módulo de Estadísticas -->
            <li class="nav-item">
                <a class="nav-link" href="charts.html">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Estadisticas</span></a>
            </li>
            <!-- Módulo de Reportes -->
            <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fa-solid fa-file-medical"></i>
                    <span>Reportes</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider d-none d-md-block">
            <!-- Botón para colapsar la barra lateral -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- Contenido principal -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Barra superior -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Botón para colapsar la barra lateral -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Menú de usuario -->
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Carlos</span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <!-- Opciones del usuario -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Configuración
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Actividad
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Cerrar Sesión
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <div class="container-fluid">
                    <!-- CRUD de pacientes -->
                    <h1 class="h3 mb-4 text-gray-800">Gestión de Pacientes</h1>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                Lista de Pacientes 
                                <span class="text-secondary">(Total: <?php echo count($pacientes); ?>)</span>
                            </h6>
                        </div>
                        <div class="card-body">
                            <!-- Buscador -->
                            <div class="input-group mb-3" style="max-width: 400px;">
                                <input type="text" id="searchInput" class="form-control" placeholder="Buscar por cualquier dato del paciente">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Cédula</th>
                                            <th>Primer Nombre</th>
                                            <th>Primer Apellido</th>
                                            <th>Edad</th>
                                            <th>Teléfono</th>
                                            <th class="direccion">Dirección</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody id="pacientes-list">
                                        <!-- Los datos se llenarán dinámicamente con JavaScript -->
                                    </tbody>
                                </table>
                            </div>
                            <!-- Paginación -->
                            <nav aria-label="Paginación">
                                <ul class="pagination justify-content-center" id="pagination">
                                    <!-- Los botones de paginación se generarán dinámicamente -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <script>
                    const pacientes = <?php echo json_encode($pacientes); ?>;
                    const rowsPerPage = 6;
                    let currentPage = 1;
                    let filteredPacientes = [...pacientes]; // Inicialmente, todos los pacientes

                    function renderTable(page) {
                        const start = (page - 1) * rowsPerPage;
                        const end = start + rowsPerPage;
                        const visiblePacientes = filteredPacientes.slice(start, end);

                        const tableBody = document.getElementById('pacientes-list');
                        tableBody.innerHTML = '';

                        visiblePacientes.forEach(paciente => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${paciente.cedula || 'N/A'}</td>
                                <td>${paciente.pr_nombre || 'N/A'}</td>
                                <td>${paciente.pr_apellido || 'N/A'}</td>
                                <td>${paciente.fecha_nacimiento ? (new Date().getFullYear() - new Date(paciente.fecha_nacimiento).getFullYear()) : 'N/A'}</td>
                                <td>${paciente.telefono || 'N/A'}</td>
                                <td class="direccion">${paciente.direccion || 'N/A'}</td>
                                <td class="text-center">
                                    <a href="#" title="Información del Paciente" class="btn btn-info btn-circle btn-sm mx-1" data-toggle="modal" data-target="#infoModal" onclick='showPatientInfo(${JSON.stringify(paciente)})'>
                                        <i class="fas fa-info-circle"></i>
                                    </a>
                                    <a href="#" title="Editar" class="btn btn-warning btn-circle btn-sm mx-1" data-toggle="modal" data-target="#editModal" onclick='showEditModal(${JSON.stringify(paciente)})'>
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="#" title="Historia Médica" class="btn btn-secondary btn-circle btn-sm mx-1" onclick="cargarHistoriaMedica('${paciente.cedula}')">
                                        <i class="fas fa-file-medical"></i>
                                    </a>
                                    <a href="#" title="Eliminar" class="btn btn-danger btn-circle btn-sm mx-1" onclick="eliminarPaciente('${paciente.cedula}')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            `;
                            tableBody.appendChild(row);
                        });

                        addTransitionEffect(tableBody);
                    }

                    function renderPagination() {
                        const totalPages = Math.ceil(filteredPacientes.length / rowsPerPage);
                        const pagination = document.getElementById('pagination');
                        pagination.innerHTML = ''; // Limpiar la paginación existente

                        if (totalPages > 1) {
                            // Botón "Anterior"
                            const prevButton = document.createElement('button');
                            prevButton.className = `btn btn-primary mx-1 ${currentPage === 1 ? 'disabled' : ''}`;
                            prevButton.innerHTML = '&laquo; Anterior';
                            prevButton.addEventListener('click', () => {
                                if (currentPage > 1) {
                                    currentPage--;
                                    renderTable(currentPage);
                                    renderPagination();
                                }
                            });
                            pagination.appendChild(prevButton);

                            // Botones de páginas
                            for (let i = 1; i <= totalPages; i++) {
                                const pageButton = document.createElement('button');
                                pageButton.className = `btn mx-1 ${i === currentPage ? 'btn-primary' : 'btn-outline-primary'}`;
                                pageButton.innerHTML = i;
                                pageButton.addEventListener('click', () => {
                                    currentPage = i;
                                    renderTable(currentPage);
                                    renderPagination();
                                });
                                pagination.appendChild(pageButton);
                            }

                            // Botón "Siguiente"
                            const nextButton = document.createElement('button');
                            nextButton.className = `btn btn-primary mx-1 ${currentPage === totalPages ? 'disabled' : ''}`;
                            nextButton.innerHTML = 'Siguiente &raquo;';
                            nextButton.addEventListener('click', () => {
                                if (currentPage < totalPages) {
                                    currentPage++;
                                    renderTable(currentPage);
                                    renderPagination();
                                }
                            });
                            pagination.appendChild(nextButton);
                        }
                    }

                    function filterPacientes(query) {
                        query = query.toLowerCase();
                        filteredPacientes = pacientes.filter(paciente => {
                            return (
                                (paciente.cedula && paciente.cedula.toLowerCase().includes(query)) ||
                                (paciente.pr_nombre && paciente.pr_nombre.toLowerCase().includes(query)) ||
                                (paciente.pr_apellido && paciente.pr_apellido.toLowerCase().includes(query)) ||
                                (paciente.telefono && paciente.telefono.toLowerCase().includes(query)) ||
                                (paciente.direccion && paciente.direccion.toLowerCase().includes(query))
                            );
                        });
                        currentPage = 1; // Reiniciar a la primera página después de filtrar
                        renderTable(currentPage);
                        renderPagination();
                    }

                    // Escuchar eventos en el campo de búsqueda
                    document.getElementById('searchInput').addEventListener('input', (e) => {
                        filterPacientes(e.target.value);
                    });

                    // Inicializar la tabla y la paginación
                    renderPagination();
                    renderTable(currentPage);
                </script>
                <script>
                    // Mostrar información completa del paciente en un modal
                    function showPatientInfo(paciente) {
                        const modalBody = document.getElementById('infoModalBody');
                        modalBody.innerHTML = `
                            <p><strong>Cédula:</strong> ${paciente.cedula || 'N/A'}</p>
                            <p><strong>Primer Nombre:</strong> ${paciente.pr_nombre || 'N/A'}</p>
                            <p><strong>Segundo Nombre:</strong> ${paciente.sdo_nombre || 'N/A'}</p>
                            <p><strong>Primer Apellido:</strong> ${paciente.pr_apellido || 'N/A'}</p>
                            <p><strong>Segundo Apellido:</strong> ${paciente.sdo_apellido || 'N/A'}</p>
                            <p><strong>Género:</strong> ${paciente.genero || 'N/A'}</p>
                            <p><strong>Fecha de Nacimiento:</strong> ${paciente.fecha_nacimiento || 'N/A'}</p>
                            <p><strong>Correo:</strong> ${paciente.correo || 'N/A'}</p>
                            <p><strong>Teléfono:</strong> ${paciente.telefono || 'N/A'}</p>
                            <p><strong>Dirección:</strong> ${paciente.direccion || 'N/A'}</p>
                            <p><strong>Estado:</strong> ${paciente.estado_nombre || 'N/A'}</p>
                            <p><strong>Municipio:</strong> ${paciente.municipio_nombre || 'N/A'}</p>
                            <p><strong>Parroquia:</strong> ${paciente.parroquia_nombre || 'N/A'}</p>
                        `;
                    }

                    // Cargar estados desde la base de datos
                    function cargarEstados(selectedEstado = '') {
                        fetch('cargar_estados.php') // Ruta revertida
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Error al cargar los estados');
                                }
                                return response.json();
                            })
                            .then(data => {
                                const estadoSelect = document.getElementById('editEstado');
                                estadoSelect.innerHTML = '<option value="">Seleccione un estado</option>';
                                data.estados.forEach(estado => {
                                    estadoSelect.innerHTML += `<option value="${estado.id_estado}" ${estado.id_estado == selectedEstado ? 'selected' : ''}>${estado.nombre}</option>`;
                                });
                            })
                            .catch(error => {
                                console.error(error);
                                Swal.fire('Error', 'No se pudieron cargar los estados', 'error');
                            });
                    }

                    // Cargar municipios según el estado seleccionado
                    function cargarMunicipios(estadoId, selectedMunicipio = '') {
                        fetch(`cargar_municipios.php?estado_id=${estadoId}`) // Ruta revertida
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Error al cargar los municipios');
                                }
                                return response.json();
                            })
                            .then(data => {
                                const municipioSelect = document.getElementById('editMunicipio');
                                municipioSelect.innerHTML = '<option value="">Seleccione un municipio</option>';
                                data.municipios.forEach(municipio => {
                                    municipioSelect.innerHTML += `<option value="${municipio.id_municipio}" ${municipio.id_municipio == selectedMunicipio ? 'selected' : ''}>${municipio.nombre}</option>`;
                                });
                            })
                            .catch(error => {
                                console.error(error);
                                Swal.fire('Error', 'No se pudieron cargar los municipios', 'error');
                            });
                    }

                    // Cargar parroquias según el municipio seleccionado
                    function cargarParroquias(municipioId, selectedParroquia = '') {
                        fetch(`cargar_parroquias.php?municipio_id=${municipioId}`) // Ruta revertida
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Error al cargar las parroquias');
                                }
                                return response.json();
                            })
                            .then(data => {
                                const parroquiaSelect = document.getElementById('editParroquia');
                                parroquiaSelect.innerHTML = '<option value="">Seleccione una parroquia</option>';
                                data.parroquias.forEach(parroquia => {
                                    parroquiaSelect.innerHTML += `<option value="${parroquia.id_parroquia}" ${parroquia.id_parroquia == selectedParroquia ? 'selected' : ''}>${parroquia.nombre}</option>`;
                                });
                            })
                            .catch(error => {
                                console.error(error);
                                Swal.fire('Error', 'No se pudieron cargar las parroquias', 'error');
                            });
                    }

                    // Mostrar modal de edición con todos los datos del paciente
                    function showEditModal(paciente) {
                        document.getElementById('editCedula').value = paciente.cedula || '';
                        document.getElementById('editPrimerNombre').value = paciente.pr_nombre || '';
                        document.getElementById('editSegundoNombre').value = paciente.sdo_nombre || '';
                        document.getElementById('editPrimerApellido').value = paciente.pr_apellido || '';
                        document.getElementById('editSegundoApellido').value = paciente.sdo_apellido || '';
                        document.getElementById('editGenero').value = paciente.genero || '';
                        document.getElementById('editFechaNacimiento').value = paciente.fecha_nacimiento || '';
                        document.getElementById('editCorreo').value = paciente.correo || '';
                        document.getElementById('editTelefono').value = paciente.telefono || '';
                        document.getElementById('editDireccion').value = paciente.direccion || '';

                        cargarEstados(paciente.id_estado);
                        cargarMunicipios(paciente.id_estado, paciente.id_municipio);
                        cargarParroquias(paciente.id_municipio, paciente.id_parroquia);
                    }

                    // Guardar cambios del paciente
                    function savePatientChanges() {
                        const pacienteEditado = {
                            cedula: document.getElementById('editCedula').value,
                            pr_nombre: document.getElementById('editPrimerNombre').value,
                            sdo_nombre: document.getElementById('editSegundoNombre').value,
                            pr_apellido: document.getElementById('editPrimerApellido').value,
                            sdo_apellido: document.getElementById('editSegundoApellido').value,
                            genero: document.getElementById('editGenero').value,
                            fecha_nacimiento: document.getElementById('editFechaNacimiento').value,
                            correo: document.getElementById('editCorreo').value,
                            telefono: document.getElementById('editTelefono').value,
                            direccion: document.getElementById('editDireccion').value,
                            id_estado: document.getElementById('editEstado').value,
                            id_municipio: document.getElementById('editMunicipio').value,
                            id_parroquia: document.getElementById('editParroquia').value
                        };

                        fetch('guardar_paciente.php', { // Ruta revertida
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(pacienteEditado)
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    title: 'Éxito',
                                    text: 'Información actualizada correctamente',
                                    icon: 'success',
                                    timer: 3000,
                                    showConfirmButton: false
                                });
                                $('#editModal').modal('hide');
                                setTimeout(() => location.reload(), 3000);
                            } else {
                                Swal.fire('Error', data.error || 'No se pudo actualizar la información', 'error');
                            }
                        })
                        .catch(error => {
                            console.error(error);
                            Swal.fire('Error', 'Ocurrió un error al guardar los cambios', 'error');
                        });
                    }

                    // Eventos para cargar municipios y parroquias dinámicamente
                    document.getElementById('editEstado').addEventListener('change', (e) => {
                        cargarMunicipios(e.target.value);
                    });

                    document.getElementById('editMunicipio').addEventListener('change', (e) => {
                        cargarParroquias(e.target.value);
                    });

                    // Eliminar paciente
                    function eliminarPaciente(cedula) {
                        Swal.fire({
                            title: '¿Estás seguro?',
                            text: "Esta acción no se puede deshacer",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d33',
                            cancelButtonColor: '#3085d6',
                            confirmButtonText: 'Sí, eliminar',
                            cancelButtonText: 'Cancelar'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                fetch('eliminar_paciente.php', { // Archivo PHP para eliminar
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ cedula })
                                })
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        Swal.fire({
                                            title: 'Eliminado',
                                            text: 'El paciente ha sido eliminado con éxito',
                                            icon: 'success',
                                            confirmButtonColor: '#d33',
                                            confirmButtonText: '<i class="fas fa-trash"></i> OK'
                                        });
                                        setTimeout(() => location.reload(), 2000); // Recargar la página tras 2 segundos
                                    } else {
                                        Swal.fire('Error', data.error || 'No se pudo eliminar el paciente', 'error');
                                    }
                                })
                                .catch(error => {
                                    console.error(error);
                                    Swal.fire('Error', 'Ocurrió un error al eliminar el paciente', 'error');
                                });
                            }
                        });
                    }

                    // Función para mostrar la alerta de carga y redirigir a la historia médica
                    function cargarHistoriaMedica(cedula) {
                        Swal.fire({
                            title: 'Cargando Historia Médica',
                            html: '<div style="display: flex; align-items: center; justify-content: center;"><i class="fas fa-user-md fa-3x fa-spin"></i><span style="margin-left: 10px;">Un médico está escribiendo...</span></div>',
                            allowOutsideClick: false,
                            showConfirmButton: false,
                            timer: 2000 // Tiempo antes de redirigir
                        }).then(() => {
                            window.location.href = `historia_medica_general.php?cedula=${cedula}`;
                        });
                    }
                </script>

                <!-- Modal para mostrar información del paciente -->
                <div class="modal fade" id="infoModal" tabindex="-1" role="dialog" aria-labelledby="infoModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="infoModalLabel">Información del Paciente</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body" id="infoModalBody">
                                <!-- La información completa del paciente se llenará dinámicamente -->
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal para editar información del paciente -->
                <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalLabel">Editar Paciente</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class="form-group">
                                        <label for="editCedula">Cédula</label>
                                        <input type="text" class="form-control" id="editCedula" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="editPrimerNombre">Primer Nombre</label>
                                        <input type="text" class="form-control" id="editPrimerNombre">
                                    </div>
                                    <div class="form-group">
                                        <label for="editSegundoNombre">Segundo Nombre</label>
                                        <input type="text" class="form-control" id="editSegundoNombre">
                                    </div>
                                    <div class="form-group">
                                        <label for="editPrimerApellido">Primer Apellido</label>
                                        <input type="text" class="form-control" id="editPrimerApellido">
                                    </div>
                                    <div class="form-group">
                                        <label for="editSegundoApellido">Segundo Apellido</label>
                                        <input type="text" class="form-control" id="editSegundoApellido">
                                    </div>
                                    <div class="form-group">
                                        <label for="editGenero">Género</label>
                                        <select class="form-control" id="editGenero">
                                            <option value="M">Masculino</option>
                                            <option value="F">Femenino</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="editFechaNacimiento">Fecha de Nacimiento</label>
                                        <input type="date" class="form-control" id="editFechaNacimiento">
                                    </div>
                                    <div class="form-group">
                                        <label for="editCorreo">Correo</label>
                                        <input type="email" class="form-control" id="editCorreo">
                                    </div>
                                    <div class="form-group">
                                        <label for="editTelefono">Teléfono</label>
                                        <input type="text" class="form-control" id="editTelefono">
                                    </div>
                                    <div class="form-group">
                                        <label for="editDireccion">Dirección</label>
                                        <textarea class="form-control" id="editDireccion"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="editEstado">Estado</label>
                                        <select class="form-control" id="editEstado">
                                            <!-- Opciones dinámicas cargadas desde la base de datos -->
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="editMunicipio">Municipio</label>
                                        <select class="form-control" id="editMunicipio">
                                            <!-- Opciones dinámicas cargadas desde la base de datos -->
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="editParroquia">Parroquia</label>
                                        <select class="form-control" id="editParroquia">
                                            <!-- Opciones dinámicas cargadas desde la base de datos -->
                                        </select>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                <button type="button" class="btn btn-primary" onclick="savePatientChanges()">Guardar Cambios</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal para cerrar sesión -->
                <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="logoutModalLabel">¿Listo para salir?</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">Seleccione "Cerrar Sesión" a continuación para finalizar su sesión actual.</div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                                <a class="btn btn-primary" href="?logout=true">Cerrar Sesión</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Scripts necesarios -->
                <script src="../dashboard/vendor/jquery/jquery.min.js"></script>
                <script src="../dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
                <script src="../dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>
                <script src="../dashboard/js/sb-admin-2.js"></script>
                <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            </div>
        </div>
    </div>
</body>
</html>