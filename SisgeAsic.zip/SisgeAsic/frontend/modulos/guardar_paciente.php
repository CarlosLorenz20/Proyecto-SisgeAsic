<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432"; // Puerto por defecto de PostgreSQL
$dbname = "bd_asic"; // Cambia esto por el nombre correcto de tu base de datos
$user = "postgres"; // Usuario de PostgreSQL
$password = "30429913"; // Contraseña del usuario

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";

$conn = pg_connect($conn_string);

// Manejo de errores para la conexión
if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// Leer los datos enviados en formato JSON
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["success" => false, "error" => "Datos no válidos"]);
    exit();
}

// Extraer los datos del paciente
$cedula = $data['cedula'];
$pr_nombre = $data['pr_nombre'];
$sdo_nombre = $data['sdo_nombre'];
$pr_apellido = $data['pr_apellido'];
$sdo_apellido = $data['sdo_apellido'];
$genero = $data['genero'];
$fecha_nacimiento = $data['fecha_nacimiento'];
$correo = $data['correo'];
$telefono = $data['telefono'];
$direccion = $data['direccion'];
$id_estado = $data['id_estado'];
$id_municipio = $data['id_municipio'];
$id_parroquia = $data['id_parroquia'];

// Actualizar los datos del paciente en la base de datos
$query = "
    UPDATE paciente
    SET 
        pr_nombre = $1,
        sdo_nombre = $2,
        pr_apellido = $3,
        sdo_apellido = $4,
        genero = $5,
        fecha_nacimiento = $6,
        correo = $7,
        telefono = $8,
        direccion = $9,
        id_estado = $10,
        id_municipio = $11,
        id_parroquia = $12
    WHERE cedula = $13
";

$result = pg_query_params($conn, $query, [
    $pr_nombre,
    $sdo_nombre,
    $pr_apellido,
    $sdo_apellido,
    $genero,
    $fecha_nacimiento,
    $correo,
    $telefono,
    $direccion,
    $id_estado,
    $id_municipio,
    $id_parroquia,
    $cedula
]);

if ($result) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => pg_last_error($conn)]);
}

// Cerrar la conexión
pg_close($conn);
?>