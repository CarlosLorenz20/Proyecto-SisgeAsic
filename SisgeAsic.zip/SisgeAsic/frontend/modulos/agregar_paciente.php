<?php
// Inicia la sesión para mantener el estado del usuario
session_start();

// Verifica si se solicita cerrar sesión
if (isset($_GET['logout'])) {
    // Destruye la sesión y redirige al login
    session_destroy();
    header('Location: ../login/login.php');
    exit();
}

// Configuración de conexión a la base de datos
$host = "localhost"; // Servidor de la base de datos
$port = "5432"; // Puerto de PostgreSQL
$dbname = "bd_asic"; // Nombre de la base de datos
$user = "postgres"; // Usuario de la base de datos
$password = "30429913"; // Contraseña del usuario

// Establece la conexión con la base de datos
$conexion = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Verifica si la conexión fue exitosa
if (!$conexion) {
    die("Error de conexión: " . pg_last_error());
}

// Consultas para obtener los datos de las tablas estado, municipio y parroquia
$estados = pg_query($conexion, "SELECT id_estado, nombre FROM estado");
$municipios = pg_query($conexion, "SELECT id_municipio, nombre, estado_id FROM municipio");
$parroquias = pg_query($conexion, "SELECT id_parroquia, nombre, municipio_id FROM parroquia");

// Consultar las cédulas de los pacientes normales
$cedulas_pacientes = pg_query($conexion, "SELECT cedula FROM paciente");

if (!$cedulas_pacientes) {
    die("Error al obtener las cédulas de los pacientes: " . pg_last_error());
}

// Verifica si las consultas se ejecutaron correctamente
if (!$estados || !$municipios || !$parroquias) {
    die("Error al ejecutar las consultas: " . pg_last_error());
}

// Procesar datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar si los datos del formulario están llegando
    error_log("Datos recibidos del formulario: " . print_r($_POST, true));

    $pr_nombre = pg_escape_string($conexion, $_POST['pr_nombre']);
    $sdo_nombre = pg_escape_string($conexion, $_POST['sdo_nombre']);
    $pr_apellido = pg_escape_string($conexion, $_POST['pr_apellido']);
    $sdo_apellido = pg_escape_string($conexion, $_POST['sdo_apellido']);
    $genero = pg_escape_string($conexion, $_POST['sexo']);
    $codigo_pais = pg_escape_string($conexion, $_POST['codigo_pais']);
    $telefono = $codigo_pais . pg_escape_string($conexion, $_POST['telefono']);
    $correo = pg_escape_string($conexion, $_POST['correo']);
    $fecha_nacimiento = pg_escape_string($conexion, $_POST['fecha_nacimiento']);
    $direccion = pg_escape_string($conexion, $_POST['direccion']);
    $id_estado = pg_escape_string($conexion, $_POST['estado']);
    $id_municipio = pg_escape_string($conexion, $_POST['municipio']);
    $id_parroquia = pg_escape_string($conexion, $_POST['id_parroquia']);

    // Validaciones
    $errores = [];

    // Validar que la fecha de nacimiento no sea futura
    if (strtotime($fecha_nacimiento) > time()) {
        $errores[] = "La fecha de nacimiento no puede ser futura.";
    }

    // Validar que el nombre y apellido no estén vacíos
    if (empty($pr_nombre) || empty($pr_apellido)) {
        $errores[] = "El primer nombre y el primer apellido son obligatorios.";
    }

    // Validar que el teléfono tenga un formato válido
    if (!preg_match('/^\+\d{1,3}\d{7,10}$/', $telefono)) {
        $errores[] = "El número de teléfono no tiene un formato válido.";
    }

    // Validar que el correo tenga un formato válido si se proporciona
    if (!empty($correo) && !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El correo electrónico no tiene un formato válido.";
    }

    // Si hay errores, mostrarlos y detener la ejecución
    if (!empty($errores)) {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error de Validación',
                        html: '" . implode('<br>', $errores) . "',
                        confirmButtonText: 'Aceptar'
                    });
                });
              </script>";
        exit();
    }

    // Verificar si es un paciente sin identificación
    if (isset($_POST['cedula_representante']) && !empty($_POST['cedula_representante'])) {
        $cedula_representante = pg_escape_string($conexion, $_POST['cedula_representante']);

        // Insertar en la tabla de niños
        $query = "INSERT INTO paciente_nino (pr_nombre, sdo_nombre, pr_apellido, sdo_apellido, cedula_representante, genero, telefono, correo, fecha_nacimiento, direccion, id_estado, id_municipio, id_parroquia, representante_id) 
                  VALUES ('$pr_nombre', '$sdo_nombre', '$pr_apellido', '$sdo_apellido', '$cedula_representante', '$genero', '$telefono', '$correo', '$fecha_nacimiento', '$direccion', '$id_estado', '$id_municipio', '$id_parroquia', 
                  (SELECT id FROM representante WHERE cedula = '$cedula_representante'))";
    } else {
        $cedula = pg_escape_string($conexion, $_POST['cedula']);

        // Insertar en la tabla de pacientes regulares
        $query = "INSERT INTO paciente (pr_nombre, sdo_nombre, pr_apellido, sdo_apellido, cedula, genero, telefono, correo, fecha_nacimiento, direccion, id_estado, id_municipio, id_parroquia) 
                  VALUES ('$pr_nombre', '$sdo_nombre', '$pr_apellido', '$sdo_apellido', '$cedula', '$genero', '$telefono', '$correo', '$fecha_nacimiento', '$direccion', '$id_estado', '$id_municipio', '$id_parroquia')";
    }

    // Registrar la consulta SQL generada
    error_log("Consulta SQL generada: $query");

    // Ejecutar la consulta
    $resultado = pg_query($conexion, $query);

    if ($resultado) {
        error_log("Paciente registrado con éxito.");
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'success',
                        title: 'Éxito',
                        text: 'Paciente registrado con éxito.',
                        confirmButtonText: 'Aceptar'
                    }).then(() => {
                        window.location.href = 'paciente.php';
                    });
                });
              </script>";
    } else {
        $error = pg_last_error($conexion);
        error_log("Error al insertar paciente: $error");
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Error al agregar el paciente: $error',
                        confirmButtonText: 'Aceptar'
                    });
                });
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Configuración básica del documento -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://kit.fontawesome.com/7a4cab1fbd.js" crossorigin="anonymous"></script>
    <title>SisgeAsic - Agregar Paciente</title>
    <link rel="icon" type="image/png" sizes="96x96" href="../img/logo2.png">
    <link href="../dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../dashboard/css/sb-admin-2.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Barra lateral de navegación -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Logo y nombre del sistema -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../dashboard/index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/logoedit.png" alt="logo" class="logo">
                </div>
                <div class="sidebar-brand-text mx-3">SisgeAsic</div>
            </a>
            <!-- Separador -->
            <hr class="sidebar-divider my-0">
            <!-- Enlace al Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="../dashboard/index.php">
                    <i class="fa-solid fa-house-medical"></i>
                    <span>Dashboard</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Encabezado de módulos -->
            <div class="sidebar-heading">Modulos</div>
            <!-- Módulo de Pacientes -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>Pacientes</span>
                </a>
                <div id="collapsePages" class="collapse show" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="paciente.php">Lista de pacientes</a>
                        <a class="collapse-item active" href="agregar_paciente.php">Agregar paciente</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Opciones:</h6>
                        <a class="collapse-item" href="historia_medica_general.php">Historia Medica</a>
                    </div>
                </div>
            </li>
            <!-- Módulo de Médicos -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-user-md" aria-hidden="true"></i>
                    <span>Medicos</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="medico.php">Lista de Medicos</a>
                        
                    </div>
                </div>
            </li>
            <!-- Módulo de Citas -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCitas" aria-expanded="true" aria-controls="collapseCitas">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Citas</span>
                </a>
                <div id="collapseCitas" class="collapse" aria-labelledby="headingCitas" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="gestion_citas.php">Gestión de Citas</a>
                        <a class="collapse-item" href="citas.php">Calendario de Citas</a>
                    </div>
                </div>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Opciones de Administrador -->
            <div class="sidebar-heading">Opciones de Administrador</div>
            <!-- Módulo de Usuarios -->
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fa-solid fa-users"></i>
                    <span>Usuarios</span></a>
            </li>
            <!-- Módulo de Especialidades -->
            <li class="nav-item">
                <a class="nav-link" href="especialidades.php">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Especialidades</span></a>
            </li>
            <!-- Módulo de Estadísticas -->
            <li class="nav-item">
                <a class="nav-link" href="charts.html">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Estadisticas</span></a>
            </li>
            <!-- Módulo de Reportes -->
            <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fa-solid fa-file-medical"></i>
                    <span>Reportes</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider d-none d-md-block">
            <!-- Botón para colapsar la barra lateral -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- Contenido principal -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Barra superior -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Botón para colapsar la barra lateral -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Menú de usuario -->
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Carlos</span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <!-- Opciones del usuario -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Configuración
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Actividad
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Cerrar Sesión
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- Contenedor principal -->
                <div class="container-fluid d-flex justify-content-center align-items-center" style="min-height: 100vh;">
                    <div class="card shadow-lg p-4" style="width: 100%; max-width: 800px;">
                        <h1 class="h3 mb-4 text-gray-800 text-center">Agregar Paciente</h1>
                        <!-- Botón con menú desplegable -->
                        <div class="dropdown text-center mb-4">
                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Seleccionar Tipo de Paciente
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="#" id="btnPacienteNormal">Paciente</a>
                                <a class="dropdown-item" href="#" id="btnPacienteNino">Paciente sin identificación</a>
                            </div>
                        </div>

                        <!-- Formulario para agregar paciente normal -->
                        <form id="formPacienteNormal" action="agregar_paciente.php" method="POST" style="display: none;">
                            <div class="row">
                                <!-- Primera columna -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="cedula">Cédula: <span class="text-danger">*</span></label>
                                        <input type="number" class="form-control" id="cedula" name="cedula" placeholder="Cédula" required>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="sdo_nombre">Segundo Nombre:</label>
                                        <input type="text" class="form-control" id="sdo_nombre" name="sdo_nombre" placeholder="Segundo Nombre">
                                    </div>
                                    <div class="form-group">
                                        <label for="sdo_apellido">Segundo Apellido:</label>
                                        <input type="text" class="form-control" id="sdo_apellido" name="sdo_apellido" placeholder="Segundo Apellido">
                                    </div>
                                    <div class="form-group">
                                        <label for="sexo">Género: <span class="text-danger">*</span></label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="sexo" id="generoMasculino" value="M" required>
                                            <label class="form-check-label" for="generoMasculino">Masculino</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="sexo" id="generoFemenino" value="F" required>
                                            <label class="form-check-label" for="generoFemenino">Femenino</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="telefono">Teléfono:</label>
                                        <div class="input-group">
                                            <select class="form-control" id="codigo_pais" name="codigo_pais" style="max-width: 150px;" required>
                                                <option value="" disabled selected>Cargando...</option>
                                            </select>
                                            <input type="text" class="form-control" id="telefono" name="telefono" placeholder="Número de Teléfono" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="fecha_nacimiento">Fecha de Nacimiento: <span class="text-danger">*</span></label>
                                        <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" required>
                                    </div>
                                    
                                </div>
                                <!-- Segunda columna -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="pr_nombre">Primer Nombre: <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="pr_nombre" name="pr_nombre" placeholder="Primer Nombre" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="pr_apellido">Primer Apellido: <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="pr_apellido" name="pr_apellido" placeholder="Primer Apellido" required>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <label for="correo">E-mail:</label>
                                        <input type="email" class="form-control" id="correo" name="correo" placeholder="ejemplo@correo.com">
                                    </div>
                                    <div class="form-group">
                                        <label for="direccion">Dirección: <span class="text-danger">*</span></label>
                                        <textarea class="form-control" id="direccion" name="direccion" rows="2" placeholder="Dirección" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="estado">Estado: <span class="text-danger">*</span></label>
                                        <select class="form-control" id="estado" name="estado" required>
                                            <option value="" disabled selected>Seleccione</option>
                                            <?php while ($estado = pg_fetch_assoc($estados)): ?>
                                                <option value="<?= $estado['id_estado'] ?>"><?= $estado['nombre'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="municipio">Municipio: <span class="text-danger">*</span></label>
                                        <select class="form-control" id="municipio" name="municipio" required>
                                            <option value="" disabled selected>Seleccione</option>
                                            <?php while ($municipio = pg_fetch_assoc($municipios)): ?>
                                                <option value="<?= $municipio['id_municipio'] ?>" data-estado="<?= $municipio['estado_id'] ?>"><?= $municipio['nombre'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="id_parroquia">Parroquia: <span class="text-danger">*</span></label>
                                        <select class="form-control" id="id_parroquia" name="id_parroquia" required>
                                            <option value="" disabled selected>Seleccione</option>
                                            <?php while ($parroquia = pg_fetch_assoc($parroquias)): ?>
                                                <option value="<?= $parroquia['id_parroquia'] ?>" data-municipio="<?= $parroquia['municipio_id'] ?>"><?= $parroquia['nombre'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- Botones -->
                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary">Agregar Paciente Normal</button>
                                <button type="reset" class="btn btn-secondary">Cancelar</button>
                            </div>
                        </form>

                        <!---------------------------------------------------------- Formulario para agregar paciente niño -------------------------------------------------------------------------------->
 
 
                        <form id="formPacienteNino" action="agregar_paciente.php" method="POST" style="display: none;">
                            <div class="row">
                                <!-- Primera columna -->
                                <div class="col-md-6">
                                    <div class="form-group position-relative">
                                        <label for="cedula_representante">Cédula del Representante: <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="cedula_representante" name="cedula_representante" placeholder="Buscar Cédula del Representante" required autocomplete="off">
                                        <div id="cedulaList" class="dropdown-menu position-absolute w-100" style="max-height: 200px; overflow-y: auto; z-index: 1050;">
                                            <?php while ($cedula = pg_fetch_assoc($cedulas_pacientes)): ?>
                                                <a class="dropdown-item" href="#" onclick="selectCedula('<?= htmlspecialchars($cedula['cedula']) ?>')">
                                                    <?= htmlspecialchars($cedula['cedula']) ?>
                                                </a>
                                            <?php endwhile; ?>
                                        </div>
                                        <div id="representanteInfo" class="mt-2" style="display: none;">
                                            <p><strong>Nombre del Representante:</strong> <span id="nombreRepresentante"></span></p>
                                            <p><strong>Teléfono:</strong> <span id="telefonoRepresentante"></span></p>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="pr_nombre">Primer Nombre: <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="pr_nombre" name="pr_nombre" placeholder="Primer Nombre" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="sdo_nombre">Segundo Nombre:</label>
                                        <input type="text" class="form-control" id="sdo_nombre" name="sdo_nombre" placeholder="Segundo Nombre">
                                    </div>
                                    <div class="form-group">
                                        <label for="sexo">Género: <span class="text-danger">*</span></label>
                                        <select class="form-control" id="sexo" name="sexo" required>
                                            <option value="" disabled selected>Seleccione</option>
                                            <option value="M">Masculino</option>
                                            <option value="F">Femenino</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="telefono">Teléfono:</label>
                                        <div class="input-group">
                                            <select class="form-control" id="codigo_pais" name="codigo_pais" style="max-width: 150px;" required>
                                                <option value="" disabled selected>Cargando...</option>
                                            </select>
                                            <input type="text" class="form-control" id="telefono" name="telefono" placeholder="Número de Teléfono" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="fecha_nacimiento">Fecha de Nacimiento: <span class="text-danger">*</span></label>
                                        <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" required>
                                    </div>
                                    
                                </div>
                                <!-- Segunda columna -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="pr_apellido">Primer Apellido: <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="pr_apellido" name="pr_apellido" placeholder="Primer Apellido" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="sdo_apellido">Segundo Apellido:</label>
                                        <input type="text" class="form-control" id="sdo_apellido" name="sdo_apellido" placeholder="Segundo Apellido">
                                    </div>
                                    <div class="form-group">
                                        <label for="correo">E-mail:</label>
                                        <input type="email" class="form-control" id="correo" name="correo" placeholder="ejemplo@correo.com">
                                    </div>
                                    <div class="form-group">
                                        <label for="direccion">Dirección: <span class="text-danger">*</span></label>
                                        <textarea class="form-control" id="direccion" name="direccion" rows="2" placeholder="Dirección" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="estado">Estado: <span class="text-danger">*</span></label>
                                        <select class="form-control" id="estado_nino" name="estado" required>
                                            <option value="" disabled selected>Seleccione</option>
                                            <?php
                                            pg_result_seek($estados, 0);
                                            while ($estado = pg_fetch_assoc($estados)): ?>
                                                <option value="<?= $estado['id_estado'] ?>"><?= $estado['nombre'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="municipio">Municipio: <span class="text-danger">*</span></label>
                                        <select class="form-control" id="municipio_nino" name="municipio" required>
                                            <option value="" disabled selected>Seleccione</option>
                                            <?php
                                            pg_result_seek($municipios, 0);
                                            while ($municipio = pg_fetch_assoc($municipios)): ?>
                                                <option value="<?= $municipio['id_municipio'] ?>" data-estado="<?= $municipio['estado_id'] ?>"><?= $municipio['nombre'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="id_parroquia">Parroquia: <span class="text-danger">*</span></label>
                                        <select class="form-control" id="id_parroquia_nino" name="id_parroquia" required>
                                            <option value="" disabled selected>Seleccione</option>
                                            <?php
                                            pg_result_seek($parroquias, 0);
                                            while ($parroquia = pg_fetch_assoc($parroquias)): ?>
                                                <option value="<?= $parroquia['id_parroquia'] ?>" data-municipio="<?= $parroquia['municipio_id'] ?>"><?= $parroquia['nombre'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <!-- Botones -->
                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary">Agregar Paciente Niño</button>
                                <button type="reset" class="btn btn-secondary">Cancelar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Modal para cerrar sesión -->
            <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="logoutModalLabel">¿Listo para salir?</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">Seleccione "Cerrar Sesión" a continuación para finalizar su sesión actual.</div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                            <a class="btn btn-primary" href="?logout=true">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal de éxito -->
            <div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="successModalLabel">Éxito</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            Paciente registrado con éxito.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts necesarios -->
    <script src="../dashboard/vendor/jquery/jquery.min.js"></script>
    <script src="../dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../dashboard/js/sb-admin-2.min.js"></script>
    <script>
        // Cargar códigos de país dinámicamente desde una API alternativa
        document.addEventListener('DOMContentLoaded', function () {
            const selectCodigoPais = document.getElementById('codigo_pais');
            fetch('https://restcountries.com/v3.1/all')
                .then(response => response.json())
                .then(data => {
                    selectCodigoPais.innerHTML = ''; // Limpiar opciones existentes
                    data.forEach(country => {
                        if (country.idd && country.idd.root && country.idd.suffixes) {
                            const codigo = `${country.idd.root}${country.idd.suffixes[0]}`;
                            const nombre = country.translations.spa?.common || country.name.common;
                            const bandera = country.flags.svg || country.flags.png;
                            const option = document.createElement('option');
                            option.value = `+${codigo}`;
                            option.innerHTML = `<img src="${bandera}" alt="${nombre}" style="width: 20px; margin-right: 5px;"> +${codigo} (${nombre})`;
                            selectCodigoPais.appendChild(option);
                        }
                    });
                })
                .catch(error => {
                    console.error('Error al cargar los códigos de país:', error);
                    selectCodigoPais.innerHTML = '<option value="" disabled>Error al cargar</option>';
                });
        });

        // Filtrar municipios y parroquias dinámicamente
        document.getElementById('estado').addEventListener('change', function () {
            const estadoId = this.value;
            const municipios = document.querySelectorAll('#municipio option');
            municipios.forEach(option => {
                option.style.display = option.getAttribute('data-estado') === estadoId ? 'block' : 'none';
            });
            document.getElementById('municipio').value = '';
            document.getElementById('id_parroquia').value = '';
        });

        document.getElementById('municipio').addEventListener('change', function () {
            const municipioId = this.value;
            const parroquias = document.querySelectorAll('#id_parroquia option');
            parroquias.forEach(option => {
                option.style.display = option.getAttribute('data-municipio') === municipioId ? 'block' : 'none';
            });
            document.getElementById('id_parroquia').value = '';
        });

        // Filtrar municipios y parroquias dinámicamente para paciente sin identificación
        document.getElementById('estado_nino').addEventListener('change', function () {
            const estadoId = this.value;
            const municipios = document.querySelectorAll('#municipio_nino option');
            municipios.forEach(option => {
                option.style.display = option.getAttribute('data-estado') === estadoId ? 'block' : 'none';
            });
            document.getElementById('municipio_nino').value = '';
            document.getElementById('id_parroquia_nino').value = '';
        });

        document.getElementById('municipio_nino').addEventListener('change', function () {
            const municipioId = this.value;
            const parroquias = document.querySelectorAll('#id_parroquia_nino option');
            parroquias.forEach(option => {
                option.style.display = option.getAttribute('data-municipio') === municipioId ? 'block' : 'none';
            });
            document.getElementById('id_parroquia_nino').value = '';
        });

        // Mostrar el formulario correspondiente según la selección
        document.getElementById('btnPacienteNormal').addEventListener('click', function () {
            document.getElementById('formPacienteNormal').style.display = 'block';
            document.getElementById('formPacienteNino').style.display = 'none';
        });

        document.getElementById('btnPacienteNino').addEventListener('click', function () {
            document.getElementById('formPacienteNino').style.display = 'block';
            document.getElementById('formPacienteNormal').style.display = 'none';
        });

        // Buscar y completar datos del representante
        document.getElementById('cedula_representante').addEventListener('input', function () {
            const input = this.value.toLowerCase();
            const items = document.querySelectorAll('#cedulaList .dropdown-item');
            let hasResults = false;

            items.forEach(item => {
                if (item.textContent.toLowerCase().includes(input)) {
                    item.style.display = 'block';
                    hasResults = true;
                } else {
                    item.style.display = 'none';
                }
            });

            document.getElementById('cedulaList').style.display = hasResults ? 'block' : 'none';
        });

        // Seleccionar una cédula del listado
        function selectCedula(cedula) {
            document.getElementById('cedula_representante').value = cedula;
            document.getElementById('cedulaList').style.display = 'none';

            // Buscar y completar datos del representante
            fetch(`buscar_representante.php?cedula=${cedula}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        document.getElementById('representanteInfo').style.display = 'block';
                        document.getElementById('nombreRepresentante').textContent = data.nombre;
                        document.getElementById('telefonoRepresentante').textContent = data.telefono;
                    } else {
                        document.getElementById('representanteInfo').style.display = 'none';
                        console.error('No se encontraron datos para la cédula proporcionada.');
                    }
                })
                .catch(error => {
                    console.error('Error al buscar el representante:', error);
                    document.getElementById('representanteInfo').style.display = 'none';
                    alert('Error al buscar los datos del representante. Por favor, intente nuevamente.');
                });
        }

        // Ocultar el listado si se hace clic fuera
        document.addEventListener('click', function (event) {
            if (!event.target.closest('#cedula_representante') && !event.target.closest('#cedulaList')) {
                document.getElementById('cedulaList').style.display = 'none';
            }
        });
    </script>
</body>

</html>