<?php
// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos PostgreSQL
$host = "localhost";
$port = "5432"; // Puerto por defecto de PostgreSQL
$dbname = "bd_asic"; // Cambia esto por el nombre correcto de tu base de datos
$user = "postgres"; // Usuario de PostgreSQL
$password = "30429913"; // Contraseña del usuario

$conn_string = "host=$host port=$port dbname=$dbname user=$user password=$password";
$conn = pg_connect($conn_string);

// Manejo de errores para la conexión
if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// Verificar si se enviaron los datos del formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cedula = $_POST['cedula'];
    $pr_nombre = $_POST['pr_nombre'];
    $sdo_nombre = $_POST['sdo_nombre'];
    $pr_apellido = $_POST['pr_apellido'];
    $sdo_apellido = $_POST['sdo_apellido'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];

    // Validar que los campos obligatorios no estén vacíos
    if (empty($cedula) || empty($pr_nombre) || empty($pr_apellido) || empty($fecha_nacimiento) || empty($telefono) || empty($direccion)) {
        die("Error: Todos los campos obligatorios deben ser completados.");
    }

    // Actualizar los datos del paciente en la base de datos
    $query = "
        UPDATE paciente
        SET 
            pr_nombre = $1,
            sdo_nombre = $2,
            pr_apellido = $3,
            sdo_apellido = $4,
            fecha_nacimiento = $5,
            telefono = $6,
            direccion = $7
        WHERE cedula = $8
    ";
    $result = pg_query_params($conn, $query, [
        $pr_nombre,
        $sdo_nombre,
        $pr_apellido,
        $sdo_apellido,
        $fecha_nacimiento,
        $telefono,
        $direccion,
        $cedula
    ]);

    if ($result) {
        // Redirigir de vuelta al listado de pacientes con un mensaje de éxito
        header("Location: paciente.php?success=1");
        exit();
    } else {
        die("Error al actualizar el paciente: " . pg_last_error($conn));
    }
}

// Cerrar la conexión a la base de datos
pg_close($conn);
?>
