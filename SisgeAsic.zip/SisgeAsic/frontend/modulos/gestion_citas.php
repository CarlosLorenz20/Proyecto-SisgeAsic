<?php
// Inicia la sesión para mantener el estado del usuario
session_start();

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario'])) {
    header('Location: ../login/login.php'); // Redirige al login si no hay sesión activa
    exit();
}

// Conexión a la base de datos
$conn = pg_connect("host=localhost dbname=bd_asic user=postgres password=30429913");

// Manejo de errores de conexión
if (!$conn) {
    die("Error de conexión a la base de datos: " . pg_last_error());
}

// Obtiene el nombre del usuario desde la base de datos
$nombre_usuario = $_SESSION['usuario'];
$query = "SELECT nombre FROM usuario WHERE nombre_usuario = $1";
$result = pg_query_params($conn, $query, array($nombre_usuario));

if ($row = pg_fetch_assoc($result)) {
    $nombre = $row['nombre']; // Obtiene el nombre desde la columna 'nombre'
} else {
    $nombre = "Usuario"; // Valor predeterminado si no se encuentra el nombre
}

// Consulta actualizada para reflejar las columnas correctas de la tabla cita
$query = "
    SELECT 
        c.id AS id_cita,
        p.pr_nombre || ' ' || p.pr_apellido AS nombre_paciente,
        m.pr_nombre || ' ' || m.pr_apellido AS nombre_medico,
        c.fecha_inicio,
        c.fecha_fin,
        c.status -- Columna para el estado de la cita
    FROM 
        cita c
    INNER JOIN 
        paciente p ON c.cedula = p.cedula
    INNER JOIN 
        medico m ON c.id_medico = m.id_medico
    ORDER BY 
        c.fecha_inicio, c.id
";
$result = pg_query($conn, $query);

if (!$result) {
    die("Error en la consulta: " . pg_last_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>SisgeAsic - Gestión de Citas</title>
    <link rel="icon" type="image/png" sizes="96x96" href="../img/logo2.png">
    <link href="../dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../dashboard/css/sb-admin-2.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://kit.fontawesome.com/7a4cab1fbd.js" crossorigin="anonymous"></script>
    <style>
        .btn-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            font-size: 16px;
            color: #fff;
        }
        .btn-warning {
            background-color: #f6c23e;
            border-color: #f6c23e;
        }
        .btn-warning:hover {
            background-color: #dda20a;
            border-color: #d8960a;
        }
        .btn-danger {
            background-color: #e74a3b;
            border-color: #e74a3b;
        }
        .btn-danger:hover {
            background-color: #c9302c;
            border-color: #ac2925;
        }
        .btn-primary {
            background-color: #4e73df;
            border-color: #4e73df;
        }
        .btn-primary:hover {
            background-color: #2e59d9;
            border-color: #2653d4;
        }
        .btn-success {
            background-color: #1cc88a;
            border-color: #1cc88a;
        }
        .btn-success:hover {
            background-color: #17a673;
            border-color: #138f65;
        }
        .btn-info {
            background-color: #36b9cc;
            border-color: #36b9cc;
        }
        .btn-info:hover {
            background-color: #2c9faf;
            border-color: #278b99;
        }
        .btn-icon:hover {
            opacity: 0.8;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
        }
    </style>
</head>

<body id="page-top">
    <div id="wrapper">
        <!-- Barra lateral de navegación -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Logo y nombre del sistema -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../dashboard/index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/logoedit.png" alt="logo" class="logo">
                </div>
                <div class="sidebar-brand-text mx-3">SisgeAsic</div>
            </a>
            <!-- Separador -->
            <hr class="sidebar-divider my-0">
            <!-- Enlace al Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="../dashboard/index.php">
                    <i class="fa-solid fa-house-medical"></i>
                    <span>Dashboard</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Encabezado de módulos -->
            <div class="sidebar-heading">Modulos</div>
            <!-- Módulo de Pacientes -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>Pacientes</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="../modulos/paciente.php">Lista de pacientes</a>
                        <a class="collapse-item" href="../modulos/agregar_paciente.php">Agregar paciente</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Opciones:</h6>
                        <a class="collapse-item" href="../modulos/historia_medica_general.php">Historia Medica</a>
                    </div>
                </div>
            </li>
            <!-- Módulo de Médicos -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-user-md" aria-hidden="true"></i>
                    <span>Medicos</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="../modulos/medico.php">Lista de Medicos</a>
                    </div>
                </div>
            </li>
            <!-- Módulo de Citas -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCitas" aria-expanded="true" aria-controls="collapseCitas">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Citas</span>
                </a>
                <div id="collapseCitas" class="collapse" aria-labelledby="headingCitas" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="../modulos/gestion_citas.php">Gestión de Citas</a>
                        <a class="collapse-item" href="../modulos/citas.php">Calendario de Citas</a>
                    </div>
                </div>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider">
            <!-- Opciones de Administrador -->
            <div class="sidebar-heading">Opciones de Administrador</div>
            <!-- Módulo de Usuarios -->
            <li class="nav-item">
                <a class="nav-link" href="404.html">
                    <i class="fa-solid fa-users"></i>
                    <span>Usuarios</span></a>
            </li>
            <!-- Módulo de Especialidades -->
            <li class="nav-item">
                <a class="nav-link" href="../modulos/especialidades.php">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Especialidades</span></a>
            </li>
            <!-- Módulo de Estadísticas -->
            <li class="nav-item">
                <a class="nav-link" href="404.html">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Estadisticas</span></a>
            </li>
            <!-- Módulo de Reportes -->
            <li class="nav-item">
                <a class="nav-link" href="404.html">
                    <i class="fa-solid fa-file-medical"></i>
                    <span>Reportes</span></a>
            </li>
            <!-- Separador -->
            <hr class="sidebar-divider d-none d-md-block">
            <!-- Botón para colapsar la barra lateral -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>

        <!-- Contenido principal -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Barra superior -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo htmlspecialchars($nombre); ?></span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="?logout=true">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Cerrar sesión
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>

                <!-- Contenedor principal -->
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Gestión de Citas</h1>
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">Lista de Citas</h6>
                            <a href="citas.php" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Agregar Cita
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>ID Cita</th>
                                            <th>Paciente</th>
                                            <th>Médico</th>
                                            <th>Fecha Inicio</th>
                                            <th>Fecha Fin</th>
                                            <th>Status</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = pg_fetch_assoc($result)): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($row['id_cita']) ?></td>
                                                <td><?= htmlspecialchars($row['nombre_paciente']) ?></td>
                                                <td><?= htmlspecialchars($row['nombre_medico']) ?></td>
                                                <td><?= htmlspecialchars($row['fecha_inicio']) ?></td>
                                                <td><?= htmlspecialchars($row['fecha_fin']) ?></td>
                                                <td>
                                                    <?= $row['status'] === 'atendida' ? '<span class="badge badge-success">Atendida</span>' : '<span class="badge badge-warning">Pendiente</span>' ?>
                                                </td>
                                                <td>
                                                    <button class="btn-icon btn-info" title="Estado de la cita" onclick="cambiarEstadoCita(<?= $row['id_cita'] ?>)">
                                                        <i class="fas fa-toggle-on"></i>
                                                    </button>
                                                    <button class="btn-icon btn-success" title="Cita atendida" onclick="marcarCitaAtendida(<?= $row['id_cita'] ?>)">
                                                        <i class="fas fa-check-circle"></i>
                                                    </button>
                                                    <a href="editar_cita.php?id=<?= $row['id_cita'] ?>" class="btn-icon btn-warning" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button class="btn-icon btn-danger" title="Eliminar" onclick="eliminarCita(<?= $row['id_cita'] ?>)">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts necesarios -->
    <script src="../dashboard/vendor/jquery/jquery.min.js"></script>
    <script src="../dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="../dashboard/js/sb-admin-2.min.js"></script>
    <script>
        function cambiarEstadoCita(id) {
            Swal.fire({
                title: '¿Cambiar estado de la cita?',
                text: "Esta acción actualizará el estado de la cita.",
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#1cc88a',
                cancelButtonColor: '#858796',
                confirmButtonText: 'Sí, cambiar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`cambiar_estado_cita.php?id=${id}`, { method: 'GET' })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Estado actualizado',
                                    text: 'El estado de la cita se ha actualizado con éxito.',
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'No se pudo actualizar el estado de la cita.',
                                    confirmButtonText: 'Aceptar'
                                });
                            }
                        })
                        .catch(error => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Ocurrió un error al intentar actualizar el estado.',
                                confirmButtonText: 'Aceptar'
                            });
                        });
                }
            });
        }

        function marcarCitaAtendida(id) {
            Swal.fire({
                title: '¿Marcar cita como atendida?',
                text: "Esta acción marcará la cita como atendida.",
                icon: 'success',
                showCancelButton: true,
                confirmButtonColor: '#1cc88a',
                cancelButtonColor: '#858796',
                confirmButtonText: 'Sí, marcar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`marcar_cita_atendida.php?id=${id}`, { method: 'GET' })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Cita atendida',
                                    text: 'La cita ha sido marcada como atendida.',
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'No se pudo marcar la cita como atendida.',
                                    confirmButtonText: 'Aceptar'
                                });
                            }
                        })
                        .catch(error => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Ocurrió un error al intentar marcar la cita como atendida.',
                                confirmButtonText: 'Aceptar'
                            });
                        });
                }
            });
        }

        function eliminarCita(id) {
            Swal.fire({
                title: '¿Está seguro?',
                text: "Esta acción no se puede deshacer.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e74a3b',
                cancelButtonColor: '#858796',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`eliminar_cita.php?id=${id}`, { method: 'GET' })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Cita eliminada',
                                    text: 'La cita ha sido eliminada con éxito.',
                                    showConfirmButton: false,
                                    timer: 2000
                                }).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'No se pudo eliminar la cita.',
                                    confirmButtonText: 'Aceptar'
                                });
                            }
                        })
                        .catch(error => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Ocurrió un error al intentar eliminar la cita.',
                                confirmButtonText: 'Aceptar'
                            });
                        });
                }
            });
        }
    </script>
</body>
</html>
