<?php
// Conexión a la base de datos PostgreSQL
$conn = pg_connect("host=localhost dbname=bd_asic user=postgres password=30429913");
if (!$conn) {
    die("Error en la conexión a la base de datos");
}

// Manejo de inserción de nuevas especialidades
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nueva_especialidad'])) {
    $nueva_especialidad = trim($_POST['nueva_especialidad']);

    if (empty($nueva_especialidad)) {
        echo "<script>alert('El campo de especialidad está vacío.');</script>";
    } else {
        $nueva_especialidad = pg_escape_string($conn, $nueva_especialidad);
        $query_insert = "INSERT INTO especialidad (nombre_especialidad) VALUES ('$nueva_especialidad')";
        $result_insert = pg_query($conn, $query_insert);

        if ($result_insert) {
            echo "<script>alert('Especialidad agregada correctamente.');</script>";
            echo "<script>window.location.href = window.location.href;</script>";
        } else {
            $error = pg_last_error($conn);
            echo "<script>alert('Error al agregar la especialidad: $error');</script>";
        }
    }
}

// Consulta para obtener las especialidades
$query = "SELECT * FROM especialidad";
$result = pg_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://kit.fontawesome.com/7a4cab1fbd.js" crossorigin="anonymous"></script>
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SisgeAsic - Panel Admin</title>
    <!--icono de pagina-->
    <link rel="icon" type="image/png" sizes="96x96" href="../img/logo2.png">

    <!-- Custom fonts for this template-->
    <link href="../dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../dashboard/css/sb-admin-2.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

</head>

<body id="page-top">
    <!---------------------------------------------Menu Lateral--------------------------------------------------->
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../dashboard/index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <!--<i class="fas fa-laugh-wink"></i>-->
                    <img src="img/logoedit.png" alt="logo" class="logo">
                </div>
                <div class="sidebar-brand-text mx-3">SisgeAsic <!--<sup>v2</sup>--></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="../dashboard/index.php">
                    <i class="fa-solid fa-house-medical"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Modulos
            </div>

            <!-------------------------------------------Modulos--------------------------------------------->

            <!-------------------------------------------Paciente-------------------------------------------->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span>Pacientes</span>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header"></h6>
                        <a class="collapse-item" href="paciente.php">Lista de pacientes</a>
                        <a class="collapse-item" href="agregar_paciente.php">Agregar paciente</a>
                        <!--<a class="collapse-item" href="forgot-password.html">Forgot Password</a>-->
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Opciones:</h6>
                        <a class="collapse-item" href="historia_medica_general.php">Historia Medica</a>
                    </div>
                </div>
            </li>
            <!----------------------------------------------------------------------------------------------->

            <!-------------------------------------------Medico---------------------------------------------->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fa fa-user-md" aria-hidden="true"></i>
                    <span>Medicos</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <!--<h6 class="collapse-header">Custom Components:</h6>-->
                        <a class="collapse-item" href="medico.php">Lista de Medicos</a>
                        <a class="collapse-item" href="agregar_medico.php">Agregar Medico</a>
                    </div>
                </div>
            </li>
            <!----------------------------------------------------------------------------------------------->

            <!-------------------------------------------Citas----------------------------------------------->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCitas" aria-expanded="true" aria-controls="collapseCitas">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Citas</span>
                </a>
                <div id="collapseCitas" class="collapse" aria-labelledby="headingCitas" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="#">Gestión de Citas</a>
                        <a class="collapse-item" href="../modulos/citas.php">Calendario de Citas</a>
                    </div>
                </div>
            </li>
            <!----------------------------------------------------------------------------------------------->

            <!-------------------------------------------Historia Medica---------------------------------------------->
            <!-------------------------------------------------------------------------------------------------------->
            
            <!-------------------------------------------Opciones del Administrador---------------------------------------------->
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Opciones de Administrador
            </div>
            <!---------------------------------------------Gestion de Usuarios--------------------------------------------------->
            <li class="nav-item">
                <a class="nav-link" href="404.html">
                    <i class="fa-solid fa-users"></i>
                    <span>Usuarios</span></a>
            </li>
            <!------------------------------------------------------------------------------------------------------------------->

            <!-------------------------------------------------Especialidades---------------------------------------------------->
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fa-solid fa-notes-medical"></i>
                    <span>Especialidades</span></a>
            </li>
            <!------------------------------------------------------Estadisticas------------------------------------------------->
            <li class="nav-item">
                <a class="nav-link" href="404.html">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Estadisticas</span></a>
            </li>
            <!------------------------------------------------------------------------------------------------------------------->

            <!----------------------------------------------------Reportes------------------------------------------------------->
            <li class="nav-item">
                <a class="nav-link" href="404.html">
                    <i class="fa-solid fa-file-medical"></i>
                    <span>Reportes</span></a>
            </li>
            <!------------------------------------------------------------------------------------------------------------------->
            
            <!-- Nav - Tablas -->
            <!--<li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Tables</span></a>
            </li>--->

            

            <!-------------------------------------------------- Divider -------------------------------------------------->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            <!-- Sidebar Message -->
            

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Buscar..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        

                        <!-- Nav Item - Messages -->
                        
                        <!---------------------------------------------------------------------------------------------------------------->

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Carlos</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Configuración
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Actividad
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Cerrar Sesión
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                        
    <!--------------------------------------------------------------------------Contenido del modulo------------------------------------------------------------------------>
                    <!-- Content Row -->
                    <div class="row">

                        <!-- Content Column -->
                        <div class="col-lg-6 mb-4">


                        </div>

                        <div class="col-lg-6 mb-4">


                        </div>
                    </div>

                    <!-- Tabla de especialidades -->
                    <div class="container mt-5">
                        <h1 class="text-center mb-4">Especialidades Médicas</h1>

                        <div class="card shadow">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0">Lista de Especialidades</h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-hover">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Nombre</th>
                                            <th scope="col" class="text-center">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = pg_fetch_assoc($result)) { ?>
                                            <tr>
                                                <td><?php echo $row['id_especialidad']; ?></td>
                                                <td><?php echo $row['nombre_especialidad']; ?></td>
                                                <td class="text-center">
                                                    <button class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit"></i> Editar
                                                    </button>
                                                    <button class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash-alt"></i> Eliminar
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="card shadow mt-4">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">Agregar Nueva Especialidad</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="form-group">
                                        <label for="nueva_especialidad">Nombre de la Especialidad</label>
                                        <input type="text" name="nueva_especialidad" id="nueva_especialidad" class="form-control" placeholder="Ingrese el nombre" required>
                                    </div>
                                    <button type="submit" class="btn btn-success btn-block">
                                        <i class="fas fa-plus"></i> Agregar Especialidad
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    

    <!--Ventana Modal Al Cerrar Sesión-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">¿Listo para salir? </h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Seleccione "Cerrar Sesión" a continuación para finalizar su Sesión actual.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-primary" href="login.html">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src=../dashboard/vendor/jquery/jquery.min.js"></script>
    <script src="../dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../dashboard/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../dashboard/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../dashboard/js/demo/chart-area-demo.js"></script>
    <script src="../dashboard/js/demo/chart-pie-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>