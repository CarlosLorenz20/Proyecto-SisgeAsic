<?php
// Configuración de conexión a la base de datos
$host = "localhost";
$port = "5432";
$dbname = "bd_asic";
$user = "postgres";
$password = "30429913";

// Establecer conexión con la base de datos
$conexion = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

// Verificar si la conexión fue exitosa
if (!$conexion) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos.']);
    exit();
}

// Verificar si se recibió la cédula
if (!isset($_GET['cedula']) || empty($_GET['cedula'])) {
    echo json_encode(['success' => false, 'message' => 'Cédula no proporcionada.']);
    exit();
}

$cedula = pg_escape_string($conexion, $_GET['cedula']);

// Consultar los datos del representante
$query = "SELECT nombre, telefono FROM representante WHERE cedula = '$cedula'";
$resultado = pg_query($conexion, $query);

// Verificar si la consulta fue exitosa
if (!$resultado) {
    echo json_encode(['success' => false, 'message' => 'Error al ejecutar la consulta.']);
    exit();
}

// Verificar si se encontraron datos
if (pg_num_rows($resultado) > 0) {
    $representante = pg_fetch_assoc($resultado);
    echo json_encode(['success' => true, 'nombre' => $representante['nombre'], 'telefono' => $representante['telefono']]);
} else {
    echo json_encode(['success' => false, 'message' => 'No se encontraron datos para la cédula proporcionada.']);
}

// Cerrar la conexión
pg_close($conexion);
?>
