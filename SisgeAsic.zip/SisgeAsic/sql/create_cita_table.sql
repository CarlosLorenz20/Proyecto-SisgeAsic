CREATE TABLE cita (
    id SERIAL PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    fecha_inicio TIMESTAMP NOT NULL,
    fecha_fin TIMESTAMP NOT NULL,
    color VARCHAR(7) NOT NULL,
    id_medico INT NOT NULL,
    cedula INT NOT NULL,
    id_especialidad INT NOT NULL,
    FOREIGN KEY (id_medico) REFERENCES medico(id_medico),
    FOREIGN KEY (cedula) REFERENCES paciente(cedula),
    FOREIGN KEY (id_especialidad) REFERENCES especialidad(id_especialidad)
);

ALTER TABLE cita ALTER COLUMN id SET DEFAULT nextval('cita_id_seq');

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'cita_id_seq') THEN
        CREATE SEQUENCE cita_id_seq START 1;
        ALTER TABLE cita ALTER COLUMN id SET DEFAULT nextval('cita_id_seq');
    END IF;
END $$;