<?php
header('Content-Type: application/json');

// Conexión a la base de datos
$host = 'localhost';
$dbname = 'bd_asic';
$username = 'postgres';
$password = '30429913';

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
    exit();
}

// Obtener las citas de la base de datos
try {
    $stmt = $pdo->query("SELECT titulo AS title, fecha_inicio AS start, fecha_fin AS end, color FROM cita");

    // Verificar si la consulta SQL se ejecuta correctamente
    if (!$stmt) {
        echo json_encode(['error' => 'Error en la consulta SQL.']);
        exit();
    }

    $citas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($citas);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error al obtener las citas: ' . $e->getMessage()]);
}
?>