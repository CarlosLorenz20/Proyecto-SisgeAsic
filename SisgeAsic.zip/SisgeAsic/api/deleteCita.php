<?php
header('Content-Type: application/json');

// Conexión a la base de datos
$host = 'localhost';
$dbname = 'bd_asic';
$username = 'postgres';
$password = '30429913';

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
    exit();
}

// Verificar si se recibió el ID de la cita
$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['id'])) {
    echo json_encode(['error' => 'ID de cita no proporcionado.']);
    exit();
}

$id = $data['id'];

// Eliminar la cita de la base de datos
try {
    $stmt = $pdo->prepare("DELETE FROM cita WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'No se encontró la cita con el ID proporcionado.']);
    }
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error al eliminar la cita: ' . $e->getMessage()]);
}