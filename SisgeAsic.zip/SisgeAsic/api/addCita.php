<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Conexión a la base de datos
$host = 'localhost';
$dbname = 'bd_asic';
$username = 'postgres';
$password = '30429913';

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
    exit();
}

// Obtener datos del cuerpo de la solicitud
$data = json_decode(file_get_contents('php://input'), true);

// Agregar validación para capturar datos y manejar errores
file_put_contents('/tmp/debug.log', "Datos recibidos: " . print_r($data, true) . "\n", FILE_APPEND);

if (!isset($data['title'], $data['start'], $data['end'], $data['color'], $data['id_medico'], $data['cedula'], $data['id_especialidad'])) {
    echo json_encode(['success' => false, 'error' => 'Datos incompletos.']);
    exit();
}

// Preparar la consulta para insertar la cita
$stmt = $pdo->prepare("INSERT INTO cita (titulo, fecha_inicio, fecha_fin, color, id_medico, cedula, id_especialidad) VALUES (:title, :start, :end, :color, :id_medico, :cedula, :id_especialidad)");

// Ejecutar la consulta y manejar errores
try {
    $stmt->execute([
        ':title' => $data['title'],
        ':start' => $data['start'],
        ':end' => $data['end'],
        ':color' => $data['color'],
        ':id_medico' => $data['id_medico'],
        ':cedula' => $data['cedula'],
        ':id_especialidad' => $data['id_especialidad']
    ]);
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    file_put_contents('/tmp/debug.log', "Error al insertar: " . $e->getMessage() . "\n", FILE_APPEND);
    echo json_encode(['success' => false, 'error' => 'Error al insertar la cita: ' . $e->getMessage()]);
}
?>