<?php
header('Content-Type: application/json');

include_once 'bdPostGre/conexion.php'; // Asegúrate de que esta ruta sea correcta

try {
    $titulo = $_POST['titulo'];
    $id_medico = $_POST['medico'];
    $cedula = $_POST['paciente'];
    $id_especialidad = $_POST['especialidad'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin = $_POST['fecha_fin'];

    // Validar datos
    if (empty($titulo) || empty($id_medico) || empty($cedula) || empty($id_especialidad) || empty($fecha_inicio) || empty($fecha_fin)) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios.']);
        exit;
    }

    // Insertar la cita en la base de datos
    $query = "INSERT INTO cita (titulo, id_medico, cedula, id_especialidad, fecha_inicio, fecha_fin, color) 
              VALUES (:titulo, :id_medico, :cedula, :id_especialidad, :fecha_inicio, :fecha_fin, '#3788d8')";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':titulo' => $titulo,
        ':id_medico' => $id_medico,
        ':cedula' => $cedula,
        ':id_especialidad' => $id_especialidad,
        ':fecha_inicio' => $fecha_inicio,
        ':fecha_fin' => $fecha_fin
    ]);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error en el servidor: ' . $e->getMessage()]);
}
?>
