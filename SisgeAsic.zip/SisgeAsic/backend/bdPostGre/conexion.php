<?php
$host = 'localhost'; // Nombre del host de la base de datos
$db = 'bd_asic'; // Nombre de la base de datos
$user = 'postgres'; // Nombre de usuario de la base de datos
$pass = '30429913'; // Contraseña del usuario de la base de datos

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$db", $user, $pass); // Crear una nueva conexión PDO (PHP Data Objects)
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Establecer el modo de error de PDO a extención
} catch (PDOException $e) {
    die('Error de conexión: ' . $e->getMessage()); // Manejar errores de conexión
}
?>