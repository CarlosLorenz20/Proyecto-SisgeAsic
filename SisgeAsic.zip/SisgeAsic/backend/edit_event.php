<?php
include_once 'bdPostGre/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idCita = $_POST['id'] ?? null;
    $titulo = $_POST['titulo'] ?? null;
    $fechaInicio = $_POST['fecha_inicio'] ?? null;
    $fechaFin = $_POST['fecha_fin'] ?? null;
    $idMedico = $_POST['medico'] ?? null;
    $idPaciente = $_POST['paciente'] ?? null;

    if ($idCita && $titulo && $fechaInicio && $fechaFin && $idMedico && $idPaciente) {
        try {
            $query = "UPDATE cita 
                      SET titulo = :titulo, fecha_inicio = :fecha_inicio, fecha_fin = :fecha_fin, id_medico = :id_medico, id_paciente = :id_paciente 
                      WHERE id = :id";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':titulo', $titulo, PDO::PARAM_STR);
            $stmt->bindParam(':fecha_inicio', $fechaInicio, PDO::PARAM_STR);
            $stmt->bindParam(':fecha_fin', $fechaFin, PDO::PARAM_STR);
            $stmt->bindParam(':id_medico', $idMedico, PDO::PARAM_INT);
            $stmt->bindParam(':id_paciente', $idPaciente, PDO::PARAM_INT);
            $stmt->bindParam(':id', $idCita, PDO::PARAM_INT);
            $stmt->execute();

            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Datos incompletos.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
}
?>
