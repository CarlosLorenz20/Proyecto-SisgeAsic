<?php
// Configuración de la conexión a la base de datos
$host = 'localhost';
$dbname = 'bd_asic'; // Cambia esto por el nombre de tu base de datos
$user = 'postgres'; // Cambia esto por tu usuario de la base de datos
$password = '30429913'; // Cambia esto por tu contraseña de la base de datos

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al conectar a la base de datos: ' . $e->getMessage()]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $medicoId = $_GET['medico_id'] ?? null;

    if ($medicoId) {
        try {
            // Verificar si el ID del médico es válido
            if (!is_numeric($medicoId)) {
                throw new Exception('El ID del médico debe ser un número.');
            }

            // Consulta ajustada para relación directa entre medico y especialidad
            $query = "SELECT e.id_especialidad, e.nombre_especialidad 
                      FROM especialidad e
                      JOIN medico m ON m.id_especialidad = e.id_especialidad
                      WHERE m.id_medico = :medico_id";

            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':medico_id', $medicoId, PDO::PARAM_INT);
            $stmt->execute();
            $especialidades = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($especialidades) {
                echo json_encode($especialidades);
            } else {
                echo json_encode(['error' => 'No se encontraron especialidades para el médico proporcionado.']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error al obtener las especialidades: ' . $e->getMessage()]);
        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode(['error' => $e->getMessage()]);
        }
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'ID del médico no proporcionado.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido.']);
}
?>
