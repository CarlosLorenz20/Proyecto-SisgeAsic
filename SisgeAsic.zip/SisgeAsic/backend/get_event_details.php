<?php
header('Content-Type: application/json');

// Habilitar la visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once 'bdPostGre/conexion.php'; // Asegúrate de que esta ruta sea correcta

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID de cita no proporcionado o inválido.']);
    exit;
}

$id = intval($_GET['id']); // Asegúrate de convertir el ID a un entero

try {
    $query = "SELECT c.id, c.titulo, 
                     TO_CHAR(c.fecha_inicio, 'YYYY-MM-DD\"T\"HH24:MI') AS fecha_inicio, 
                     TO_CHAR(c.fecha_fin, 'YYYY-MM-DD\"T\"HH24:MI') AS fecha_fin, 
                     c.color, 
                     m.id_medico, m.pr_nombre AS medico_nombre, m.pr_apellido AS medico_apellido,
                     p.cedula, p.pr_nombre AS paciente_nombre, p.pr_apellido AS paciente_apellido
              FROM cita c
              JOIN medico m ON c.id_medico = m.id_medico
              JOIN paciente p ON c.cedula = p.cedula
              WHERE c.id = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $cita = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($cita) {
        echo json_encode(['success' => true, 'data' => $cita]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Cita no encontrada.']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error en el servidor: ' . $e->getMessage()]);
}
?>
