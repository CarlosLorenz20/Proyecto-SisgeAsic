<?php
include_once 'bdPostGre/conexion.php'; // Asegúrate de que la conexión esté configurada correctamente

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Obtener el ID de la cita desde los parámetros de la URL
    $id = $_GET['id'] ?? null;

    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'ID de cita no proporcionado.']);
        exit;
    }

    try {
        // Preparar la consulta para eliminar la cita
        $query = "DELETE FROM cita WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Cita eliminada correctamente.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No se pudo eliminar la cita.']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error en la base de datos: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
}
?>
