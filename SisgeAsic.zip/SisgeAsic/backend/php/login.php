<?php
// Configuración de la base de datos
$host = 'localhost';
$db = 'bd_asic';
$user = 'postgres';
$pass = '30429913';

try {
    // Crear una nueva conexión PDO para PostgreSQL
    $pdo = new PDO("pgsql:host=$host;dbname=$db", $user, $pass);
    // Establecer el modo de error de PDO a excepción
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Manejar errores de conexión
    echo 'Error de conexión: ' . $e->getMessage();
}
?>
