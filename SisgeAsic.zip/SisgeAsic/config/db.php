<?php
$servername = "localhost";
$username = "postgres"; // Cambia esto si usas otro usuario
$password = "30429913"; // Cambia esto si tienes una contraseña
$database = "bd_asic"; // Cambia esto por el nombre de tu base de datos

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
